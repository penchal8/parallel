

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;


public class NCL10 extends JFrame implements ActionListener
{
	
	
	Container c;
	
	
	
	Font f1 = new Font("Times New Roman",Font.BOLD,18);
	
	Font f3 = new Font("Times New Roman",Font.BOLD,25);
	
	Font f2 = new Font("Times New Roman",Font.BOLD,16);
	
	
	JLabel status,info;
	JMenuBar mb;
	JMenu m;
	JMenuItem m1,m2,m3,mi1;
	ImageIcon i12 = new ImageIcon(this.getClass().getResource("12.png"));

	ImageIcon i17 = new ImageIcon(this.getClass().getResource("17.png"));

	
	ImageIcon g12 = new ImageIcon(this.getClass().getResource("g12.png"));
	
	ImageIcon g17 = new ImageIcon(this.getClass().getResource("g17.png"));

	
	ImageIcon gd = new ImageIcon(this.getClass().getResource("gd.png"));
	ImageIcon bd = new ImageIcon(this.getClass().getResource("bd.png"));
	
	ImageIcon bl10 = new ImageIcon(this.getClass().getResource("bl10.png"));
	ImageIcon bl11 = new ImageIcon(this.getClass().getResource("bl11.png"));
	ImageIcon bl12 = new ImageIcon(this.getClass().getResource("bl12.png"));
	
	ImageIcon gl10 = new ImageIcon(this.getClass().getResource("gl10.png"));
	ImageIcon gl11 = new ImageIcon(this.getClass().getResource("gl11.png"));
	ImageIcon gl12 = new ImageIcon(this.getClass().getResource("gl12.png"));
	
	ImageIcon rl10 = new ImageIcon(this.getClass().getResource("rl10.png"));
	ImageIcon rl11 = new ImageIcon(this.getClass().getResource("rl11.png"));
	ImageIcon rl12 = new ImageIcon(this.getClass().getResource("rl12.png"));
	
	ImageIcon gr = new ImageIcon(this.getClass().getResource("gr.png"));
	ImageIcon br = new ImageIcon(this.getClass().getResource("br.png"));
	
	ImageIcon gsp = new ImageIcon(this.getClass().getResource("gsp.png"));
	ImageIcon bsp = new ImageIcon(this.getClass().getResource("bsp.png"));
	
	JLabel lbd1,lbd2,lbd3,li1211,li1212,li1213,li1214,li1215,li1216,li122,li123,li171,li172,li173,lbl101,lbl102,lbl103,
	lbl111,lbl112,lbl113,lbl121,lbl122,lbl123,lbr1,lbr2,lbr3,lbsp1,lbsp2,lbsp3;
	String destip,filename;
	NCL10()
	{
		c=getContentPane();
		c.setLayout(null);
		c.setBackground(Color.white);
		setTitle("NCL-10::Cooperative Caching for Efficient Data Access in Disruption Tolerant Networks");
		
		mb = new JMenuBar();
		m = new JMenu("File");
		mi1 = new JMenuItem("NCL Data Details");
		m1 = new JMenuItem("Attacker Details");
		m2 = new JMenuItem("Response Details");
		m3 = new JMenuItem("Exit");
		m.add(mi1);
		m.add(m1);
		m.add(m2);
		m.add(m3);
		mb.add(m);
		setJMenuBar(mb);
		Border b11=BorderFactory.createLineBorder(Color.black,2);
		TitledBorder b22=new TitledBorder(b11);
		b22.setTitle("NCL-10");
		b22.setTitleColor(Color.blue);
		b22.setTitleFont(f2);
		JLabel bord =new JLabel();
		bord.setBorder(b22);
		bord.setBackground(Color.black);
		bord.setBounds(10, 100, 500, 190);
		c.add(bord);
		
		
		 ImageIcon banner = new ImageIcon(this.getClass().getResource("NCL.png"));
		 JLabel title = new JLabel();
		 title.setIcon(banner);
		 title.setBounds(0, -10, 550,80);
	
		
	
		lbsp1=new JLabel();
		lbsp1.setIcon(bsp);
		lbsp1.setBounds(40,50, 200, 200);
		c.add(lbsp1);
		
		li1211=new JLabel();
		li1211.setIcon(i12);
		li1211.setBounds(120,50, 200, 200);
		c.add(li1211);

		lbr1=new JLabel();
		lbr1.setIcon(br);
		lbr1.setBounds(200,50, 200, 200);
		c.add(lbr1);
		
		li1212=new JLabel();
		li1212.setIcon(i12);
		li1212.setBounds(280,50, 200, 200);
		c.add(li1212);
		
		lbd1=new JLabel();
		lbd1.setIcon(bd);
		lbd1.setBounds(363,50, 200, 200);
		c.add(lbd1);
		
		li171=new JLabel();
		li171.setIcon(i17);
		li171.setBounds(230,110, 200, 200);
		c.add(li171);
		
		lbl101=new JLabel();
		lbl101.setIcon(bl10);
		lbl101.setBounds(215,160, 200, 200);
		c.add(lbl101);
		c.add(title);
		
	
		 m1.addActionListener(this);
		 mi1.addActionListener(this);
		 m2.addActionListener(this);
		 m3.addActionListener(this);
		setSize(550,370);
		setVisible(true);
		
		int[] ports = new int[]{701,801};
		
		
		for(int i=0;i<2;i++)
		{
			Thread th = new Thread(new portlistener(ports[i]));
			th.start();
		}
		
		
		
	}
	
	
	public class portlistener implements Runnable
	{
		int port;
		
		portlistener(int port)
		{
			this.port=port;
		}
		
		public void run()
		{

			
			if(this.port==801)
			{
				try
				{
					ServerSocket sc = new ServerSocket(801);
					while(true)
					{
						Socket s = sc.accept();
						ObjectInputStream din = new ObjectInputStream(s.getInputStream());
						
							String filename = (String)din.readObject();
							if (filename.toLowerCase().endsWith(".java")
									|| filename.toLowerCase().endsWith(".txt")
									|| filename.toLowerCase().endsWith(".log"))
							{
								String sk = (String)din.readObject();
								String ip =(String) din.readObject();
								
								lbd1.setVisible(false);
								lbd1.setIcon(gd);
								lbd1.setVisible(true);
								 Thread.sleep(1000); 
								 li1212.setVisible(false);
									li1212.setIcon(g12);
									li1212.setVisible(true);
									 Thread.sleep(1000);
									 lbr1.setVisible(false);
										lbr1.setIcon(gr);
										lbr1.setVisible(true);
										 Thread.sleep(1000);
								li171.setVisible(false);
									li171.setIcon(g17);
									li171.setVisible(true);
									 Thread.sleep(1000);
									 lbl101.setVisible(false);
										lbl101.setIcon(gl10);
										lbl101.setVisible(true);
										 Thread.sleep(1000);
							
								DBCon db = new DBCon();
								 Connection con = db.getConnection();
									
									SimpleDateFormat sdfDate = new SimpleDateFormat(
											"dd/MM/yyyy");
									SimpleDateFormat sdfTime = new SimpleDateFormat(
											"HH:mm:ss");

									Date now = new Date();

									String strDate = sdfDate.format(now);
									String strTime = sdfTime.format(now);
									String dt = strDate + "   " + strTime;
									Statement stmt = con.createStatement();
									String sql = "select * from ncl where  filename='"+filename+"' and nclname='NCL10'";
									ResultSet rs = stmt.executeQuery(sql);
												
									if(rs.next()==true)
									{
										Statement stmt1 = con.createStatement();
										String sql1 = "select * from ncl where  filename='"+filename+"' and sk='"+sk+"' and nclname='NCL10'";
										ResultSet rs1 = stmt1.executeQuery(sql1);
										if(rs1.next()==true)
										{
											
											FileInputStream fin = new FileInputStream("NCL/NCL10/"+filename);
											byte[] b = new byte[fin.available()];
											fin.read(b);
											
											String st = new String(b);
											
											Statement stmt2 = con.createStatement();
											String sql2 = "insert into response values('NCL10','"+filename+"','"+sk+"','"+ip+"','"+dt+"')";
											 stmt2.executeUpdate(sql2);
											 
											ObjectOutputStream oout = new ObjectOutputStream(s.getOutputStream());
											System.out.println("success");
											oout.writeObject("success");
											
											oout.writeObject(st);
											
											Thread.sleep(1000);
											lbl101.setVisible(false);
											lbl101.setIcon(gl10);
											lbl101.setVisible(true);
											 Thread.sleep(1000);
											 li171.setVisible(false);
												li171.setIcon(g17);
												li171.setVisible(true);
												 Thread.sleep(1000);
													lbr1.setVisible(false);
													lbr1.setIcon(gr);
													lbr1.setVisible(true);
													 Thread.sleep(1000);
											 
											li1212.setVisible(false);
											li1212.setIcon(g12);
											li1212.setVisible(true);
											 Thread.sleep(1000);
											
											lbd1.setVisible(false);
											lbd1.setIcon(gd);
											lbd1.setVisible(true);
											 Thread.sleep(1000);
											 
											 Thread.sleep(3000);
											 refresh();
											
											
											
											
											
										}
										else if(rs1.next()==false)
										{
											lbl101.setVisible(false);
											lbl101.setIcon(rl10);
											lbl101.setVisible(true);
											 Thread.sleep(1000);
											Statement stmt2 = con.createStatement();
											String sql2 = "insert into Hacker values('NCL10','"+ip+"','"+filename+"','"+sk+"','"+dt+"')";
											 stmt2.executeUpdate(sql2);
											ObjectOutputStream oout = new ObjectOutputStream(s.getOutputStream());
											oout.writeObject("failure");
											

											Thread.sleep(1000);
											lbl101.setVisible(false);
											lbl101.setIcon(rl10);
											lbl101.setVisible(true);
											 Thread.sleep(1000);
											 li171.setVisible(false);
												li171.setIcon(g17);
												li171.setVisible(true);
												 Thread.sleep(1000);
													lbr1.setVisible(false);
													lbr1.setIcon(gr);
													lbr1.setVisible(true);
													 Thread.sleep(1000);
											
											 
											 Thread.sleep(3000);
											 refresh();
										}
									}
									else if(rs.next()==false)
									{
										Thread.sleep(1000);
										lbl101.setVisible(false);
										lbl101.setIcon(rl10);
										lbl101.setVisible(true);
										 Thread.sleep(1000);
										 li171.setVisible(false);
											li171.setIcon(g17);
											li171.setVisible(true);
											 Thread.sleep(1000);
												lbr1.setVisible(false);
												lbr1.setIcon(gr);
												lbr1.setVisible(true);
												 Thread.sleep(1000);
										ObjectOutputStream oout = new ObjectOutputStream(s.getOutputStream());
										oout.writeObject("not");
										Thread.sleep(3000);
										 refresh();
									}
							}
							else
							{
								String sk = (String)din.readObject();
								String ip =(String) din.readObject();
								
								lbd1.setVisible(false);
								lbd1.setIcon(gd);
								lbd1.setVisible(true);
								 Thread.sleep(1000); 
								 li1212.setVisible(false);
									li1212.setIcon(g12);
									li1212.setVisible(true);
									 Thread.sleep(1000);
									 lbr1.setVisible(false);
										lbr1.setIcon(gr);
										lbr1.setVisible(true);
										 Thread.sleep(1000);
								li171.setVisible(false);
									li171.setIcon(g17);
									li171.setVisible(true);
									 Thread.sleep(1000);
									 lbl101.setVisible(false);
										lbl101.setIcon(gl10);
										lbl101.setVisible(true);
										 Thread.sleep(1000);
										 
								DBCon db = new DBCon();
								 Connection con = db.getConnection();
									
									SimpleDateFormat sdfDate = new SimpleDateFormat(
											"dd/MM/yyyy");
									SimpleDateFormat sdfTime = new SimpleDateFormat(
											"HH:mm:ss");

									Date now = new Date();

									String strDate = sdfDate.format(now);
									String strTime = sdfTime.format(now);
									String dt = strDate + "   " + strTime;
									Statement stmt = con.createStatement();
									String sql = "select * from ncl where  filename='"+filename+"' and nclname='NCL10'";
									ResultSet rs = stmt.executeQuery(sql);
												
									if(rs.next()==true)
									{
										Statement stmt1 = con.createStatement();
										String sql1 = "select * from ncl where  filename='"+filename+"' and sk='"+sk+"' and nclname='NCL10'";
										ResultSet rs1 = stmt1.executeQuery(sql1);
										if(rs1.next()==true)
										{
											
											FileInputStream fin = new FileInputStream("NCL/NCL10/"+filename);
											byte[] b = new byte[fin.available()];
											fin.read(b);
											
											
											
											Statement stmt2 = con.createStatement();
											String sql2 = "insert into response values('NCL10','"+filename+"','"+sk+"','"+ip+"','"+dt+"')";
											 stmt2.executeUpdate(sql2);
											 
											ObjectOutputStream oout = new ObjectOutputStream(s.getOutputStream());
											System.out.println("success");
											oout.writeObject("success");
											
											oout.writeObject(b);
											lbl101.setVisible(false);
											lbl101.setIcon(gl10);
											lbl101.setVisible(true);
											 Thread.sleep(1000);
											 li171.setVisible(false);
												li171.setIcon(g17);
												li171.setVisible(true);
												 Thread.sleep(1000);
													lbr1.setVisible(false);
													lbr1.setIcon(gr);
													lbr1.setVisible(true);
													 Thread.sleep(1000);
											 
											li1212.setVisible(false);
											li1212.setIcon(g12);
											li1212.setVisible(true);
											 Thread.sleep(1000);
											
											lbd1.setVisible(false);
											lbd1.setIcon(gd);
											lbd1.setVisible(true);
											 Thread.sleep(1000);
											 
											 Thread.sleep(3000);
											 refresh();
											
											
										}
										else if(rs1.next()==false)
										{
											lbl101.setVisible(false);
											lbl101.setIcon(rl10);
											lbl101.setVisible(true);
											 Thread.sleep(1000);
											Statement stmt2 = con.createStatement();
											String sql2 = "insert into Hacker values('NCL10','"+ip+"','"+filename+"','"+sk+"','"+dt+"')";
											 stmt2.executeUpdate(sql2);
											ObjectOutputStream oout = new ObjectOutputStream(s.getOutputStream());
											oout.writeObject("failure");
											Thread.sleep(1000);
											lbl101.setVisible(false);
											lbl101.setIcon(rl10);
											lbl101.setVisible(true);
											 Thread.sleep(1000);
											 li171.setVisible(false);
												li171.setIcon(g17);
												li171.setVisible(true);
												 Thread.sleep(1000);
													lbr1.setVisible(false);
													lbr1.setIcon(gr);
													lbr1.setVisible(true);
													 Thread.sleep(1000);
											
											 
											 Thread.sleep(3000);
											 refresh();
										}
									}
									else if(rs.next()==false)
									{
										Thread.sleep(1000);
										lbl101.setVisible(false);
										lbl101.setIcon(rl10);
										lbl101.setVisible(true);
										 Thread.sleep(1000);
										 li171.setVisible(false);
											li171.setIcon(g17);
											li171.setVisible(true);
											 Thread.sleep(1000);
												lbr1.setVisible(false);
												lbr1.setIcon(gr);
												lbr1.setVisible(true);
												 Thread.sleep(1000);
										ObjectOutputStream oout = new ObjectOutputStream(s.getOutputStream());
										oout.writeObject("not");
										Thread.sleep(3000);
										 refresh();
									}
							}
							
							
							
					}
				}catch(Exception e)
				{
					e.printStackTrace();
				}
			}
				
			if(this.port==701)
			{
				
				try
				{
					
					 
					ServerSocket sc = new ServerSocket(701);
					while(true)
					{
						Socket s = sc.accept();
						ObjectInputStream din = new ObjectInputStream(s.getInputStream());
						 String filename =(String) din.readObject();
						 if (filename.toLowerCase().endsWith(".java")
									|| filename.toLowerCase().endsWith(".txt")
									|| filename.toLowerCase().endsWith(".log"))
							{
							 
							String content = (String)din.readObject();
								
							 String sk=(String)din.readObject();
							 String sip=(String)din.readObject();
							 
							    lbsp1.setVisible(false);
								lbsp1.setIcon(gsp);
								lbsp1.setVisible(true);
								 Thread.sleep(1000);
								
								li1211.setVisible(false);
								li1211.setIcon(g12);
								li1211.setVisible(true);
								 Thread.sleep(1000);

								lbr1.setVisible(false);
								lbr1.setIcon(gr);
								lbr1.setVisible(true);
								 Thread.sleep(1000);
								
								li171.setVisible(false);
								li171.setIcon(g17);
								li171.setVisible(true);
								 Thread.sleep(1000);
								
								lbl101.setVisible(false);
								lbl101.setIcon(gl10);
								lbl101.setVisible(true);
								 Thread.sleep(1000);
								
								
							 
							 DBCon db = new DBCon();
							 Connection con = db.getConnection();
								
								SimpleDateFormat sdfDate = new SimpleDateFormat(
										"dd/MM/yyyy");
								SimpleDateFormat sdfTime = new SimpleDateFormat(
										"HH:mm:ss");

								Date now = new Date();

								String strDate = sdfDate.format(now);
								String strTime = sdfTime.format(now);
								String dt = strDate + "   " + strTime;
																				
								Statement stmt1 = con.createStatement();
								String sql1 = "insert into ncl values('NCL10','"+filename+"','"+sk+"','"+sip+"','"+dt+"')";
								stmt1.executeUpdate(sql1);
								
								
								
								PrintStream p = new PrintStream(new FileOutputStream("NCL/NCL10/"+filename));
								p.print(new String(content));
								
								ObjectOutputStream dout = new ObjectOutputStream(s.getOutputStream());
								dout.writeObject("success");
								
								
								 Thread.sleep(1000);
								lbl101.setVisible(false);
								lbl101.setIcon(gl10);
								lbl101.setVisible(true);
								 Thread.sleep(1000);
								 li171.setVisible(false);
									li171.setIcon(g17);
									li171.setVisible(true);
									 Thread.sleep(1000);
										lbr1.setVisible(false);
										lbr1.setIcon(gr);
										lbr1.setVisible(true);
										 Thread.sleep(1000);
								 
								li1212.setVisible(false);
								li1212.setIcon(g12);
								li1212.setVisible(true);
								 Thread.sleep(1000);
								
								lbd1.setVisible(false);
								lbd1.setIcon(gd);
								lbd1.setVisible(true);
								 Thread.sleep(1000);
								 
								 Thread.sleep(3000);
								 refresh();
								
							}
						 else
						 {
							 byte[] content = (byte[])din.readObject();
								
							 String sk=(String)din.readObject();
							 String sip=(String)din.readObject();
							 
							    lbsp1.setVisible(false);
								lbsp1.setIcon(gsp);
								lbsp1.setVisible(true);
								 Thread.sleep(1000);
								
								li1211.setVisible(false);
								li1211.setIcon(g12);
								li1211.setVisible(true);
								 Thread.sleep(1000);

								lbr1.setVisible(false);
								lbr1.setIcon(gr);
								lbr1.setVisible(true);
								 Thread.sleep(1000);
								
								li171.setVisible(false);
								li171.setIcon(g17);
								li171.setVisible(true);
								 Thread.sleep(1000);
								
								lbl101.setVisible(false);
								lbl101.setIcon(gl10);
								lbl101.setVisible(true);
								 Thread.sleep(1000);
								
							 
							 DBCon db = new DBCon();
							 Connection con = db.getConnection();
								
								SimpleDateFormat sdfDate = new SimpleDateFormat(
										"dd/MM/yyyy");
								SimpleDateFormat sdfTime = new SimpleDateFormat(
										"HH:mm:ss");

								Date now = new Date();

								String strDate = sdfDate.format(now);
								String strTime = sdfTime.format(now);
								String dt = strDate + "   " + strTime;
																				
								Statement stmt1 = con.createStatement();
								String sql1 = "insert into ncl values('NCL10','"+filename+"','"+sk+"','"+sip+"','"+dt+"')";
								stmt1.executeUpdate(sql1);
								
								
									FileOutputStream fos = new FileOutputStream("NCL/NCL10/"+ filename);
									fos.write(content);
									fos.close();
									ObjectOutputStream dout = new ObjectOutputStream(s.getOutputStream());
									dout.writeObject("success");
									
								
								
								 Thread.sleep(1000);
								lbl101.setVisible(false);
								lbl101.setIcon(gl10);
								lbl101.setVisible(true);
								 Thread.sleep(1000);
								 li171.setVisible(false);
									li171.setIcon(g17);
									li171.setVisible(true);
									 Thread.sleep(1000);
										lbr1.setVisible(false);
										lbr1.setIcon(gr);
										lbr1.setVisible(true);
										 Thread.sleep(1000);
								 
								li1212.setVisible(false);
								li1212.setIcon(g12);
								li1212.setVisible(true);
								 Thread.sleep(1000);
								
								lbd1.setVisible(false);
								lbd1.setIcon(gd);
								lbd1.setVisible(true);
								 Thread.sleep(1000);
								 
								 Thread.sleep(3000);
								 refresh();
								 
							 
						 }
						 
					}
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
			}
		}
	}
	
	public void actionPerformed(ActionEvent e)
	{
			
		if(e.getSource()==m3)
		{
		System.exit(0);
			
		}
		if(e.getSource()==mi1)
		{
			
			try {
				UIManager
						.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			java.awt.EventQueue.invokeLater(new Runnable() {
				public void run() {
					new nlc10data();
				}
			});
	}
		else if(e.getSource()==m1)
		{
			
			try {
				UIManager
						.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			java.awt.EventQueue.invokeLater(new Runnable() {
				public void run() {
					new attacker10();
				}
			});
		}
		else if(e.getSource()==m2)
		{
			
			try {
				UIManager
						.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			java.awt.EventQueue.invokeLater(new Runnable() {
				public void run() {
					new response10();
				}
			});
		}
		
		
	}
	
	public void refresh()
	{
		try
		{
			 Thread.sleep(1000);
			 lbsp1.setVisible(false);
				lbsp1.setIcon(bsp);
				lbsp1.setVisible(true);
				
				
				li1211.setVisible(false);
				li1211.setIcon(i12);
				li1211.setVisible(true);
				

				lbr1.setVisible(false);
				lbr1.setIcon(br);
				lbr1.setVisible(true);
				
				
				li171.setVisible(false);
				li171.setIcon(i17);
				li171.setVisible(true);
				
				
				lbl101.setVisible(false);
				lbl101.setIcon(bl10);
				lbl101.setVisible(true);
				 
				 
				 li1212.setVisible(false);
					li1212.setIcon(i12);
					li1212.setVisible(true);
				
					
					lbd1.setVisible(false);
					lbd1.setIcon(bd);
					lbd1.setVisible(true);
					
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
		
		
	}
	
	
	
	public static void main(String[] args) {
		//new Router();
		try {
			UIManager
					.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new NCL10();
			}
		});
	}
	
	

}

		