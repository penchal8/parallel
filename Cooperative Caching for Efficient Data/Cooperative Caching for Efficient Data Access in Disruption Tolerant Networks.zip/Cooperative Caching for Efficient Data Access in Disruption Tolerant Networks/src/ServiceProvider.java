import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Desktop;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.io.PrintStream;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;




public class ServiceProvider implements ActionListener
{		
	byte[] b;
	String dd;
	String txtstr=null;
	String hash;
	String filename;
	String content,path1;
	public Font f = new Font("Verdana" , Font.BOLD , 22);	
	public Font f1 = new Font("Times new roman", Font.BOLD , 15);
	public Font f2 = new Font("Arial", Font.BOLD , 12);
	public Font f3 = new Font("Times new roman", Font.BOLD , 16);
	public JLabel T0= new JLabel();

	public JLabel confirm=new JLabel();
	
	public JLabel T2= new JLabel("Path of The File");
	
	public JLabel T4= new JLabel();
	
	
	public JButton btn = new JButton("Send");
	public JTextArea tf = new JTextArea();
	public JScrollPane pane = new JScrollPane();
	public JButton btn1 = new JButton("Browse");
	public JButton btn2 = new JButton("Exit");
 	
	public JTextField txt=new JTextField();
	public JTextField txt1=new JTextField();
	public JTextField txt2=new JTextField();
	 
		public JLabel  leftButton;
		
		JLabel back= new JLabel();
	public JFrame jf;
	public Container c;
	String event;

	String send,event1,event2;
	String keyword = "2d2b3bef2bfa3a8cfdb0277b25ed94d79ca0cb99";
	JMenuBar mb;
	JMenu m;
	JMenuItem m1,m2,m3,mi1;
	
	
	ServiceProvider()
	{	
		
		jf = new JFrame("Service Provider::Cooperative Caching for Efficient Data Access in Disruption Tolerant Networks");
		c = jf.getContentPane();
		c.setLayout(null);
		jf.setSize(900,580);
		jf.setResizable(false);  
		c.setBackground(Color.white);
		
		mb = new JMenuBar();
		m = new JMenu("File");
		
		m1 = new JMenuItem("File Transfer Details");
		m2 = new JMenuItem("Request Log Details");
		m3 = new JMenuItem("Exit");
		m.add(m1);
		m.add(m2);
	//	m.add(m3);
		mb.add(m);
		Border b11=BorderFactory.createLineBorder(Color.black,2);
		
		jf.setJMenuBar(mb);
		TitledBorder b22=new TitledBorder(b11);
		b22.setTitle("File Transfering");
		b22.setTitleColor(Color.blue);
		b22.setTitleFont(f2);
		JLabel bord =new JLabel();
		bord.setBorder(b22);
		bord.setBackground(Color.black);
		bord.setBounds(10,140,500,350);
		c.add(bord);
		
//		T0.setBounds(180,15,200,150);
//	    T0.setIcon(greengr);
		
		
		
		 ImageIcon banner = new ImageIcon(this.getClass().getResource("ServiceProvider.png"));
		 JLabel title = new JLabel();
		 title.setIcon(banner);
		 title.setBounds(0, -10, 900,110);

		 ImageIcon banner1 = new ImageIcon(this.getClass().getResource("SPBanner.png"));
		 JLabel title1 = new JLabel();
		 title1.setIcon(banner1);
		 title1.setBounds(520, 200, 450,275);
	   
	    T0.setForeground(Color.CYAN);
		T2.setBounds(15, 190, 250,45);
		T2.setFont(f2);
		T2.setForeground(Color.blue);
		
		
		txt1.setBounds(105, 200, 300,25);
		txt1.setForeground(Color.MAGENTA);
	    txt1.setFont(f1);

		T4.setBounds(225, 540, 250,45);
		T4.setFont(f2);
		T4.setForeground(Color.RED);
		
		
		txt2.setBounds(220, 595, 250,30);
		txt2.setForeground(Color.BLUE);
	    txt2.setFont(f1);
	   confirm.setBounds(445, 520, 250,45);
	    
	    confirm.setForeground(new Color(255,0,0));

		btn.setBounds(100,430,120,30);
		btn2.setBounds(290,430,120,30);
	//	btn.setFont(f3);
		
		btn1.setBounds(420,198,70,25);
		
		txt.setBounds(260,150,180,25);
		txt.setForeground(Color.BLUE);
		txt.setFont(f3);
		
		pane.setBounds(105, 250, 300, 150);
		
		tf.setColumns(20);
		
		tf.setForeground(Color.MAGENTA);
		tf.setFont(f1);
		tf.setRows(10);
		tf.setName("tf");
		pane.setName("pane");
		pane.setViewportView(tf);
		
		btn1.addActionListener(this);
		btn.addActionListener(this);
		btn2.addActionListener(this);
		 m1.addActionListener(this);
		
		 m2.addActionListener(this);
		 m3.addActionListener(this);
		 txt2.setEnabled(false);
		
		jf.show();
	 	
	 	c.add(txt1);
	 
		c.add(btn);
		c.add(btn2);
		c.add(confirm);
		c.add(T2);
		//c.add(T3);
		c.add(T4);
		//c.add(T5);
		c.add(pane, BorderLayout.CENTER);
		c.add(btn1);
		c.add(T0);
		c.add(title);
		c.add(title1);
		jf.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent win) {
				System.exit(0);
			}
		});
		
		int[] ports = new int[]{900};
		
		
		for(int i=0;i<1;i++)
		{
			Thread th = new Thread(new portlistener(ports[i]));
			th.start();
		}
		
	}		
	
	
	public class portlistener implements Runnable
	{
		int port;
		
		portlistener(int port)
		{
			this.port=port;
		}
		
		public void run()
		{

			
			

			if(this.port==900)
			{
				try
				{
					ServerSocket sc = new ServerSocket(900);
					while(true)
					{
						Socket s = sc.accept();
						ObjectInputStream din = new ObjectInputStream(s.getInputStream());
							String filename1 = (String)din.readObject();
							String sk = (String)din.readObject();
							String ip = (String)din.readObject();
							String dname = (String)din.readObject();
							DBCon db = new DBCon();
							 Connection con = db.getConnection();
								
								SimpleDateFormat sdfDate = new SimpleDateFormat(
										"dd/MM/yyyy");
								SimpleDateFormat sdfTime = new SimpleDateFormat(
										"HH:mm:ss");

								Date now = new Date();

								String strDate = sdfDate.format(now);
								String strTime = sdfTime.format(now);
								String dt = strDate + "   " + strTime;
								Statement stmt2 = con.createStatement();
								String sql2 = "insert into request values('"+filename1+"','"+sk+"','"+ip+"','"+dt+"')";
								 stmt2.executeUpdate(sql2);
							JOptionPane.showMessageDialog(null, filename1+" is Requested by Reciever:- "+ip );
							int i = JOptionPane.showConfirmDialog(null, "Do you want to Send File to Reciever");
							if(i==0)
							{
								
								JFileChooser chooser = new JFileChooser();

								try {

									File f = new File(new File("filename.txt").getCanonicalPath());

									chooser.setSelectedFile(f);
								} catch (IOException e1) {
								}

								chooser.showOpenDialog(btn1);
								int retval = chooser.showOpenDialog(btn1);
								if (retval == JFileChooser.APPROVE_OPTION) {
									File field = chooser.getSelectedFile();
									 path1=field.getAbsolutePath();
									 filename = field.getName();
									 txt1.setText(path1);
								}
								File curFile = chooser.getSelectedFile();
								
								
									
									FileInputStream fstream = new FileInputStream(curFile);
									b = new byte[fstream.available()];
									fstream.read(b);
									 content = new String(b);
									 
									 KeyGenerator kgenerate = new KeyGenerator();
									 String sk1 = String.valueOf(kgenerate.getKeys());
									 
									 InetAddress ia = InetAddress.getLocalHost();
										String ip1= ia.getHostAddress();
										
									 Statement stmt1 = con.createStatement();
										String sql1 = "insert into files values('"+filename+"','"+sk1+"','"+ip1+"','"+ip+"','"+dname+"','"+dt+"')";
										stmt1.executeUpdate(sql1);
										
									 if (filename.toLowerCase().endsWith(".java")
												|| filename.toLowerCase().endsWith(".txt")
												|| filename.toLowerCase().endsWith(".log"))
										{
									
									tf.setText(content);
									
									AES a2= new AES();
									
										PrintStream p = new PrintStream(new FileOutputStream("Source/"+filename));
										p.print(new String(a2.encrypt(content,keyword)));
										
										ObjectOutputStream dout1 = new ObjectOutputStream(s.getOutputStream());
			            				 dout1.writeObject("success");
			            				 dout1.writeObject(filename);
			            				 dout1.writeObject(a2.encrypt(content,keyword));
			            				 dout1.writeObject(sk1);
			            				 dout1.writeObject(ip1);
										}
									 else
									 {
										 tf.setText(path1);
										 PrintStream p = new PrintStream(new FileOutputStream("Source/"+filename));
											p.print(b);
											
											ObjectOutputStream dout1 = new ObjectOutputStream(s.getOutputStream());
				            				 dout1.writeObject("success");
				            				 dout1.writeObject(filename);
				            				 dout1.writeObject(b);
				            				 dout1.writeObject(sk1);
				            				 dout1.writeObject(ip1);
									 }
								
									 JOptionPane.showMessageDialog(null, filename+" as been Send to "+dname);
							}
							else if(i==1)
							{
								 ObjectOutputStream dout1 = new ObjectOutputStream(s.getOutputStream());
	            				 dout1.writeObject("fail");
							}
							
					}
				}catch (Exception e1) {
					System.err.println("Error: " + e1.getMessage());
				}
			}
		}
				
	
	}
		public void actionPerformed(ActionEvent e)
		 {		
		    	ObjectInputStream input;

		    	BufferedInputStream bis;
		    	BufferedOutputStream bos = null;
		    	BufferedWriter writer = null;
		    	int in;
		    	String str="MobileTerminal,Foriegn Agent  A,Gateway FA  A";
		    	byte[] byteArray=str.getBytes();
		    	StringBuffer buffer = new StringBuffer();
		    			    			 
			    String strLine = null;
			    String newline = "\n";
			    
			    
			    
			    if (e.getSource() == btn1) {

					

			    	JFileChooser chooser = new JFileChooser();

					try {

						File f = new File(new File("filename.txt").getCanonicalPath());

						chooser.setSelectedFile(f);
					} catch (IOException e1) {
					}

					chooser.showOpenDialog(btn1);
					int retval = chooser.showOpenDialog(btn1);
					if (retval == JFileChooser.APPROVE_OPTION) {
						File field = chooser.getSelectedFile();
						 path1=field.getAbsolutePath();
						 filename = field.getName();
						 txt1.setText(path1);
					}
					File curFile = chooser.getSelectedFile();

					try {
						
						FileInputStream fstream = new FileInputStream(curFile);
						b = new byte[fstream.available()];
						fstream.read(b);
						 content = new String(b);
						 if (filename.toLowerCase().endsWith(".java")
									|| filename.toLowerCase().endsWith(".txt")
									|| filename.toLowerCase().endsWith(".log"))
							{
						
						tf.setText(content);
						
						AES a2= new AES();
						
							PrintStream p = new PrintStream(new FileOutputStream("Source/"+filename));
							p.print(new String(a2.encrypt(content,keyword)));
							}
						 else
						 {
							 tf.setText(path1);
							 PrintStream p = new PrintStream(new FileOutputStream("Source/"+filename));
								p.print(b);
						 }
						 
					} catch (Exception e1) {
						System.err.println("Error: " + e1.getMessage());
					}
				}
			    
			 if(e.getSource()== btn)
			 {
				 				
			
				    
					try {
						KeyGenerator kgenerate = new KeyGenerator();
						 String sk = String.valueOf(kgenerate.getKeys());
							AES a2= new AES();
							
							InetAddress ia = InetAddress.getLocalHost();
							String ip1= ia.getHostAddress();
						String[] dsname = { "Select Destination", "A", "B", "C", "D", "E", "F" };
						
						String dataname = (String) JOptionPane.showInputDialog(null,
								"Select Destination", "Destination Name",
								JOptionPane.QUESTION_MESSAGE, null,  dsname,  dsname[0]);
					 
						String dest = JOptionPane.showInputDialog(null,
								"Please Enter the IP Address Of "+dataname);
						String ip = JOptionPane.showInputDialog(null,
								"Please Enter the IP Address Of Router");

                             
						
						
						 DBCon db = new DBCon();
						 Connection con = db.getConnection();
							
							SimpleDateFormat sdfDate = new SimpleDateFormat(
									"dd/MM/yyyy");
							SimpleDateFormat sdfTime = new SimpleDateFormat(
									"HH:mm:ss");

							Date now = new Date();

							String strDate = sdfDate.format(now);
							String strTime = sdfTime.format(now);
							String dt = strDate + "   " + strTime;
																			
							Statement stmt1 = con.createStatement();
							String sql1 = "insert into files values('"+filename+"','"+sk+"','"+ip1+"','"+dest+"','"+dataname+"','"+dt+"')";
							stmt1.executeUpdate(sql1);
						
						
							if (filename.toLowerCase().endsWith(".java")
									|| filename.toLowerCase().endsWith(".txt")
									|| filename.toLowerCase().endsWith(".log"))
							{
                             Socket sc1 = new Socket(ip,202);
            				 ObjectOutputStream dout1 = new ObjectOutputStream(sc1.getOutputStream());
            				 dout1.writeObject(filename);
            				 dout1.writeObject(a2.encrypt(content,keyword));
            				 dout1.writeObject(sk);
            				 dout1.writeObject(dataname);
            				 dout1.writeObject(dest);
            				 dout1.writeObject(ip1);
            				 
            				 ObjectInputStream din1 = new ObjectInputStream(sc1.getInputStream());
            				 String msg1 = (String)din1.readObject();
            				
            					 JOptionPane.showMessageDialog(null, msg1);
							}
							else
							{
								
								Socket sc1 = new Socket(ip,202);
	            				 ObjectOutputStream dout1 = new ObjectOutputStream(sc1.getOutputStream());
	            				 dout1.writeObject(filename);
	            				 dout1.writeObject(b);
	            				 dout1.writeObject(sk);
	            				 dout1.writeObject(dataname);
	            				 dout1.writeObject(dest);
	            				 dout1.writeObject(ip1);
	            				 
	            				 ObjectInputStream din1 = new ObjectInputStream(sc1.getInputStream());
	            				 String msg1 = (String)din1.readObject();
	            				
	            					 JOptionPane.showMessageDialog(null, msg1);
							}
            				 

					
						
						}
						
						
						
						catch (UnknownHostException e1) {
						
						e1.printStackTrace();
					} catch (Exception e1) {}
						
					finally {
						
					}
			 
				 	
			 }
			 if(e.getSource()== btn2)
			 {
				
				 System.exit(0);
				
				 
			 }
			
				if(e.getSource()==m1)
				{
					try {
						UIManager
								.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
					} catch (Exception e1) {
						e1.printStackTrace();
					}
					java.awt.EventQueue.invokeLater(new Runnable() {
						public void run() {
							new filedetails();
						}
					});
			}
				else if(e.getSource()==m2)
				{
					
					try {
						UIManager
								.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
					} catch (Exception e1) {
						e1.printStackTrace();
					}
					java.awt.EventQueue.invokeLater(new Runnable() {
						public void run() {
							new requestdetails();
						}
					});
				}
				
	
			 
			 }
		
	public static void main(String args[])
	{
		//new ServiceProvider();
		try {
			UIManager
					.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new ServiceProvider();
			}
		});
	}
}
	
	
	

		


