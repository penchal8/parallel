import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.FileInputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.UIManager;


public class Router extends JFrame implements ActionListener
{
	
	
	Container c;
	
	
	
	Font f1 = new Font("Times New Roman",Font.BOLD,18);
	
	Font f3 = new Font("Times New Roman",Font.BOLD,25);
	
	Font f2 = new Font("Times New Roman",Font.BOLD,16);
	
	
	JLabel status,info;
//	JMenuBar mb;
//	JMenu m;
//	JMenuItem m1,m2,m3,mi1;
	
	
	
	
	ImageIcon bn1 = new ImageIcon(this.getClass().getResource("bn1.png"));
	ImageIcon bn2 = new ImageIcon(this.getClass().getResource("bn2.png"));
	ImageIcon bn3 = new ImageIcon(this.getClass().getResource("bn3.png"));
	ImageIcon bn4 = new ImageIcon(this.getClass().getResource("bn4.png"));
	ImageIcon bn5 = new ImageIcon(this.getClass().getResource("bn5.png"));
	ImageIcon bn6 = new ImageIcon(this.getClass().getResource("bn6.png"));
	ImageIcon bn7 = new ImageIcon(this.getClass().getResource("bn7.png"));
	ImageIcon bn8 = new ImageIcon(this.getClass().getResource("bn8.png"));
	ImageIcon bn9 = new ImageIcon(this.getClass().getResource("bn9.png"));
	ImageIcon bn10 = new ImageIcon(this.getClass().getResource("bn10.png"));
	ImageIcon bn11 = new ImageIcon(this.getClass().getResource("bn11.png"));
	ImageIcon bn12 = new ImageIcon(this.getClass().getResource("bn12.png"));
	ImageIcon bn13 = new ImageIcon(this.getClass().getResource("bn13.png"));
	ImageIcon bn14 = new ImageIcon(this.getClass().getResource("bn14.png"));
	ImageIcon bn15 = new ImageIcon(this.getClass().getResource("bn15.png"));
	
	
	ImageIcon gn1 = new ImageIcon(this.getClass().getResource("gn1.png"));
	ImageIcon gn2 = new ImageIcon(this.getClass().getResource("gn2.png"));
	ImageIcon gn3 = new ImageIcon(this.getClass().getResource("gn3.png"));
	ImageIcon gn4 = new ImageIcon(this.getClass().getResource("gn4.png"));
	ImageIcon gn5 = new ImageIcon(this.getClass().getResource("gn5.png"));
	ImageIcon gn6 = new ImageIcon(this.getClass().getResource("gn6.png"));
	ImageIcon gn7 = new ImageIcon(this.getClass().getResource("gn7.png"));
	ImageIcon gn8 = new ImageIcon(this.getClass().getResource("gn8.png"));
	ImageIcon gn9 = new ImageIcon(this.getClass().getResource("gn9.png"));
	ImageIcon gn10 = new ImageIcon(this.getClass().getResource("gn10.png"));
	ImageIcon gn11 = new ImageIcon(this.getClass().getResource("gn11.png"));
	ImageIcon gn12 = new ImageIcon(this.getClass().getResource("gn12.png"));
	ImageIcon gn13 = new ImageIcon(this.getClass().getResource("gn13.png"));
	ImageIcon gn14 = new ImageIcon(this.getClass().getResource("gn14.png"));
	ImageIcon gn15 = new ImageIcon(this.getClass().getResource("gn15.png"));
	
	
	ImageIcon rn10 = new ImageIcon(this.getClass().getResource("rn10.png"));
	ImageIcon rn11 = new ImageIcon(this.getClass().getResource("rn11.png"));
	ImageIcon rn12 = new ImageIcon(this.getClass().getResource("rn12.png"));
	
	
	
	ImageIcon bs1 = new ImageIcon(this.getClass().getResource("bs1.png"));
	ImageIcon gs1 = new ImageIcon(this.getClass().getResource("gs1.png"));
	
	ImageIcon bd1 = new ImageIcon(this.getClass().getResource("bd1.png"));
	ImageIcon gd1 = new ImageIcon(this.getClass().getResource("gd1.png"));
	
	
	ImageIcon i1 = new ImageIcon(this.getClass().getResource("1.png"));
	ImageIcon i2 = new ImageIcon(this.getClass().getResource("2.png"));
	ImageIcon i3 = new ImageIcon(this.getClass().getResource("3.png"));
	ImageIcon i4 = new ImageIcon(this.getClass().getResource("4.png"));
	ImageIcon i5 = new ImageIcon(this.getClass().getResource("5.png"));
	ImageIcon i6 = new ImageIcon(this.getClass().getResource("6.png"));
	ImageIcon i7 = new ImageIcon(this.getClass().getResource("7.png"));
	ImageIcon i14 = new ImageIcon(this.getClass().getResource("14.png"));

	ImageIcon g1 = new ImageIcon(this.getClass().getResource("g1.png"));
	ImageIcon g2 = new ImageIcon(this.getClass().getResource("g2.png"));
	ImageIcon g3 = new ImageIcon(this.getClass().getResource("g3.png"));
	ImageIcon g4 = new ImageIcon(this.getClass().getResource("g4.png"));
	ImageIcon g5 = new ImageIcon(this.getClass().getResource("g5.png"));
	ImageIcon g6 = new ImageIcon(this.getClass().getResource("g6.png"));
	ImageIcon g7 = new ImageIcon(this.getClass().getResource("g7.png"));
	ImageIcon g14 = new ImageIcon(this.getClass().getResource("g14.png"));
	ImageIcon g11 = new ImageIcon(this.getClass().getResource("g11.png"));
	
	ImageIcon gd = new ImageIcon(this.getClass().getResource("gd.png"));
	ImageIcon n1ar = new ImageIcon(this.getClass().getResource("n1ar.png"));
	ImageIcon n2ar = new ImageIcon(this.getClass().getResource("n2ar.png"));
	ImageIcon n12d = new ImageIcon(this.getClass().getResource("n12d.png"));
	ImageIcon d2n1 = new ImageIcon(this.getClass().getResource("d2n1.png"));
	ImageIcon ar10 = new ImageIcon(this.getClass().getResource("10ar.png"));
	ImageIcon ar11 = new ImageIcon(this.getClass().getResource("11ar.png"));
	ImageIcon ar12 = new ImageIcon(this.getClass().getResource("12ar.png"));
	
	
	JLabel lgd,ln1ar,lndar,ln12d,ld2n1,lar10,lar11,lar12,lg11,lg12,lg13;
	JLabel linf1,linf2,linf3,lb1,lb2,lb3,l41,l42,l43;
	
	JLabel lbn1,lbn2,lbn3,lbn4,lbn5,lbn6,lbn7,lbn8,lbn9,lbn10,lbn11,lbn12,lbn13,lbn14,lbn15; 

	JLabel lbs1,lbd1,ljam,li1,li2,li3,li4,li5,li6,li7,li8,li9,li10,li11,li12,li13,li14,li15;
	JLabel li21,li22,li23,li24,li25,li26,li27,li28,li29,li210,li211,li212,li213;
	JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13;
	JLabel l31,l32,l33,l34,l35,l36,l37,l38,l39,l310,l311,l312,l313;
	
	
	String destip,filename;
	
	
	
	int tn1,tn2,tn3;
	
	Router()
	{
		c=getContentPane();
		c.setLayout(null);
		c.setBackground(Color.white);
		
//		mb = new JMenuBar();
//		m = new JMenu("File");
//		mi1 = new JMenuItem("Assign Bandwidth for Nodes");
//		m1 = new JMenuItem("Attacker Details");
//		m2 = new JMenuItem("Nodes Status Details");
//		m3 = new JMenuItem("Exit");
//		m.add(mi1);
//		m.add(m1);
//		m.add(m2);
//		m.add(m3);
//		mb.add(m);
		
		lgd=new JLabel();
		lgd.setIcon(gd);
		lgd.setBounds(490,-30, 200, 200);
		c.add(lgd);
		

		ln1ar=new JLabel();
		ln1ar.setIcon(n2ar);
		ln1ar.setBounds(155,53, 300, 180);
		c.add(ln1ar);
		
		lndar=new JLabel();
		lndar.setIcon(n1ar);
		lndar.setBounds(710,63, 300, 250);
		c.add(lndar);
		
		ln12d=new JLabel();
		ln12d.setIcon(n12d);
		ln12d.setBounds(163,-288, 400, 700);
		c.add(ln12d);
		
		ld2n1=new JLabel();
		ld2n1.setIcon(d2n1);
		ld2n1.setBounds(558,-35, 200, 200);
		c.add(ld2n1);
		
		lar10=new JLabel();
		lar10.setIcon(ar10);
		lar10.setBounds(515,58, 200, 200);
		c.add(lar10);
		
		lar11=new JLabel();
		lar11.setIcon(ar11);
		lar11.setBounds(515,93, 250, 250);
		c.add(lar11);
		
		lar12=new JLabel();
		lar12.setIcon(ar12);
		lar12.setBounds(515,90, 290, 355);
		c.add(lar12);
		
		
//		 setJMenuBar(mb);
//		 m1.addActionListener(this);
//		 mi1.addActionListener(this);
//		 m2.addActionListener(this);
//		 m3.addActionListener(this);
		setTitle("Router");
		
		lbs1=new JLabel();
		lbs1.setIcon(bs1);
		lbs1.setBounds(-15, 230, 200, 200);
		c.add(lbs1);
		
		lbn1=new JLabel();
		lbn1.setIcon(bn1);
		lbn1.setBounds(140,140, 200, 200);
		c.add(lbn1);
		
		lbn2=new JLabel();
		lbn2.setIcon(bn2);
		lbn2.setBounds(140,240, 200, 200);
		c.add(lbn2);
		
		lbn3=new JLabel();
		lbn3.setIcon(bn3);
		lbn3.setBounds(140,340, 200, 200);
		c.add(lbn3);
		
		lbn4=new JLabel();
		lbn4.setIcon(bn4);
		lbn4.setBounds(250,140, 200, 200);
		c.add(lbn4);
		
		lbn5=new JLabel();
		lbn5.setIcon(bn5);
		lbn5.setBounds(250,240, 200, 200);
		c.add(lbn5);
		
		lbn6=new JLabel();
		lbn6.setIcon(bn6);
		lbn6.setBounds(250,340, 200, 200);
		c.add(lbn6);
		
		lbn7=new JLabel();
		lbn7.setIcon(bn7);
		lbn7.setBounds(363,140, 200, 200);
		c.add(lbn7);
		
		lbn8=new JLabel();
		lbn8.setIcon(bn8);
		lbn8.setBounds(363,240, 200, 200);
		c.add(lbn8);
		
		lbn9=new JLabel();
		lbn9.setIcon(bn9);
		lbn9.setBounds(363,340, 200, 200);
		c.add(lbn9);
		
		lbn10=new JLabel();
		lbn10.setIcon(bn10);
		lbn10.setBounds(450,130, 200, 200);
		c.add(lbn10);
		
		lbn11=new JLabel();
		lbn11.setIcon(bn11);
		lbn11.setBounds(450,230, 200, 200);
		c.add(lbn11);
		
		lbn12=new JLabel();
		lbn12.setIcon(bn12);
		lbn12.setBounds(450,330, 200, 200);
		c.add(lbn12);
		
		lbn13=new JLabel();
		lbn13.setIcon(bn13);
		lbn13.setBounds(575,140, 200, 200);
		c.add(lbn13);
		
		lbn14=new JLabel();
		lbn14.setIcon(bn14);
		lbn14.setBounds(575,240, 200, 200);
		c.add(lbn14);
		
		lbn15=new JLabel();
		lbn15.setIcon(bn15);
		lbn15.setBounds(575,340, 200, 200);
		c.add(lbn15);
		
		lg11=new JLabel();
		lg11.setIcon(g11);
		lg11.setBounds(470,143, 200, 200);
		c.add(lg11);
		
		lg12=new JLabel();
		lg12.setIcon(g11);
		lg12.setBounds(470,243, 200, 200);
		c.add(lg12);
		
		lg13=new JLabel();
		lg13.setIcon(g11);
		lg13.setBounds(470,343, 200, 200);
		c.add(lg13);
		
		li1=new JLabel();
		li1.setIcon(i1);
		li1.setBounds(40,180, 200, 200);
		c.add(li1);
		
		li2=new JLabel();
		li2.setIcon(i2);
		li2.setBounds(60,240, 200, 200);
		c.add(li2);
		
		li3=new JLabel();
		li3.setIcon(i3);
		li3.setBounds(40,295, 200, 200);
		c.add(li3);
		
		li4=new JLabel();
		li4.setIcon(i7);
		li4.setBounds(150,195, 200, 200);
		c.add(li4);
		
		li5=new JLabel();
		li5.setIcon(i7);
		li5.setBounds(150,295, 200, 200);
		c.add(li5);
		
		li6=new JLabel();
		li6.setIcon(i4);
		li6.setBounds(177,140, 200, 200);
		c.add(li6);
		
		li7=new JLabel();
		li7.setIcon(i4);
		li7.setBounds(177,240, 200, 200);
		c.add(li7);
		
		li8=new JLabel();
		li8.setIcon(i4);
		li8.setBounds(177,340, 200, 200);
		c.add(li8);
		
		li9=new JLabel();
		li9.setIcon(i7);
		li9.setBounds(260,195, 200, 200);
		c.add(li9);
		
		li10=new JLabel();
		li10.setIcon(i7);
		li10.setBounds(260,295, 200, 200);
		c.add(li10);
		
		li11=new JLabel();
		li11.setIcon(i4);
		li11.setBounds(288,140, 200, 200);
		c.add(li11);
		
		li12=new JLabel();
		li12.setIcon(i4);
		li12.setBounds(288,240, 200, 200);
		c.add(li12);
		
		li13=new JLabel();
		li13.setIcon(i4);
		li13.setBounds(288,340, 200, 200);
		c.add(li13);
		
		li14=new JLabel();
		li14.setIcon(i7);
		li14.setBounds(373,195, 200, 200);
		c.add(li14);
		
		li15=new JLabel();
		li15.setIcon(i7);
		li15.setBounds(373,295, 200, 200);
		c.add(li15);
		
		li21=new JLabel();
		li21.setIcon(i14);
		li21.setBounds(395,140, 200, 200);
		c.add(li21);
		
		li22=new JLabel();
		li22.setIcon(i14);
		li22.setBounds(395,240, 200, 200);
		c.add(li22);
		
		li23=new JLabel();
		li23.setIcon(i4);
		li23.setBounds(395,340, 200, 200);
		c.add(li23);
		
		li24=new JLabel();
		li24.setIcon(i7);
		li24.setBounds(472,175, 200, 200);
		c.add(li24);
		
		li25=new JLabel();
		li25.setIcon(i7);
		li25.setBounds(472,275, 200, 200);
		c.add(li25);
		
		li26=new JLabel();
		li26.setIcon(i4);
		li26.setBounds(500,140, 200, 200);
		c.add(li26);
		
		li27=new JLabel();
		li27.setIcon(i4);
		li27.setBounds(500,240, 200, 200);
		c.add(li27);
		
		li28=new JLabel();
		li28.setIcon(i4);
		li28.setBounds(500,340, 200, 200);
		c.add(li28);
		
		li29=new JLabel();
		li29.setIcon(i7);
		li29.setBounds(585,195, 200, 200);
		c.add(li29);
		
		li210=new JLabel();
		li210.setIcon(i7);
		li210.setBounds(585,295, 200, 200);
		c.add(li210);
		
		li211=new JLabel();
		li211.setIcon(i5);
		li211.setBounds(613,177, 200, 200);
		c.add(li211);
		
		li212=new JLabel();
		li212.setIcon(i2);
		li212.setBounds(618,240, 200, 200);
		c.add(li212);
		
		li213=new JLabel();
		li213.setIcon(i6);
		li213.setBounds(610,300, 200, 200);
		c.add(li213);
		
		lbd1=new JLabel();
		lbd1.setIcon(bd1);
		lbd1.setBounds(680,235, 200, 200);
		c.add(lbd1);
		
		l1=new JLabel("1");
		l1.setFont(f2);
		l1.setForeground(Color.blue);
		l1.setBounds(90,170, 200, 200);
		c.add(l1);
		
		l2=new JLabel("2");
		l2.setFont(f2);
		l2.setForeground(Color.blue);
		l2.setBounds(100,230, 200, 200);
		c.add(l2);
		
		l3=new JLabel("3");
		l3.setFont(f2);
		l3.setForeground(Color.blue);
		l3.setBounds(100,310, 200, 200);
		c.add(l3);
		
		l4=new JLabel("NCL-1");
		l4.setFont(f2);
		l4.setForeground(Color.blue);
		l4.setBounds(435,110, 200, 200);
		c.add(l4);
		
		l5=new JLabel("NCL-2");
		l5.setFont(f2);
		l5.setForeground(Color.blue);
		l5.setBounds(435,210, 200, 200);
		c.add(l5);
		
		l6=new JLabel("NCL-3");
		l6.setFont(f2);
		l6.setForeground(Color.blue);
		l6.setBounds(435,310, 200, 200);
		c.add(l6);
		
		
		/*lgd.setVisible(false);
		ln1ar.setVisible(false);
		lndar.setVisible(false);
		ln12d.setVisible(false);
		ld2n1.setVisible(false);
		lar10.setVisible(false);
		lar11.setVisible(false);
		lar12.setVisible(false);
		lg11.setVisible(false);
		lg12.setVisible(false);
		lg13.setVisible(false);
		l1.setVisible(false);
		l2.setVisible(false);
		l3.setVisible(false);*/
		setSize(800,600);
		setVisible(true);
		
		int[] ports = new int[]{201,202,203,204,205,206,302};
		
		
		for(int i=0;i<7;i++)
		{
			Thread th = new Thread(new portlistener(ports[i]));
			th.start();
		}
		
		
		
	}
	
	
	public class portlistener implements Runnable
	{
		int port;
		
		portlistener(int port)
		{
			this.port=port;
		}
		
		public void run()
		{

			
			

			if(this.port==302)
			{
				try
				{
					ServerSocket sc = new ServerSocket(302);
					while(true)
					{
						Socket s = sc.accept();
						ObjectInputStream din = new ObjectInputStream(s.getInputStream());
							String filename = (String)din.readObject();
							String sk = (String)din.readObject();
							String ip =(String) din.readObject();
							String dname =(String) din.readObject();
							
							lndar.setVisible(false);
							ld2n1.setVisible(false);
							lgd.setVisible(false);
							ln1ar.setVisible(false);
							
							ln12d.setVisible(false);
							
							lar10.setVisible(false);
							lar11.setVisible(false);
							lar12.setVisible(false);
							lg11.setVisible(false);
							lg12.setVisible(false);
							lg13.setVisible(false);
							
							Socket sc1 = new Socket("localhost",801);
							ObjectOutputStream dout1 = new ObjectOutputStream(sc1.getOutputStream());					
							dout1.writeObject(filename);
							dout1.writeObject(sk);
							dout1.writeObject(ip);
							
							ObjectInputStream oin = new ObjectInputStream(sc1.getInputStream());
							String msg1 =(String)oin.readObject();
							System.out.println(msg1);
							
							
							if(msg1.equalsIgnoreCase("success"))
							{
								
								if (filename.toLowerCase().endsWith(".java")
										|| filename.toLowerCase().endsWith(".txt")
										|| filename.toLowerCase().endsWith(".log"))
								{
									String ct = (String)oin.readObject();
									ObjectOutputStream dout2 = new ObjectOutputStream(s.getOutputStream());					
									dout2.writeObject("success");
									dout2.writeObject(ct);
								}
								else
								{
									byte[] ct = (byte[])oin.readObject();
									ObjectOutputStream dout2 = new ObjectOutputStream(s.getOutputStream());					
									dout2.writeObject("success");
									dout2.writeObject(ct);
								}
								
							}
							else if(msg1.equalsIgnoreCase("failure"))
							{
								ObjectOutputStream dout2 = new ObjectOutputStream(s.getOutputStream());					
								dout2.writeObject("failure");
								
							}
							else if(msg1.equalsIgnoreCase("not"))
							{
								//2
								Socket sc2 = new Socket("localhost",802);
								ObjectOutputStream dout3 = new ObjectOutputStream(sc2.getOutputStream());					
								dout3.writeObject(filename);
								dout3.writeObject(sk);
								dout3.writeObject(ip);
								
								ObjectInputStream oin2 = new ObjectInputStream(sc2.getInputStream());
								String msg2 =(String)oin2.readObject();
								System.out.println(msg2);
								
								
								if(msg2.equalsIgnoreCase("success"))
								{
									if (filename.toLowerCase().endsWith(".java")
											|| filename.toLowerCase().endsWith(".txt")
											|| filename.toLowerCase().endsWith(".log"))
									{
										String ct = (String)oin2.readObject();
										ObjectOutputStream dout2 = new ObjectOutputStream(s.getOutputStream());					
										dout2.writeObject("success");
										dout2.writeObject(ct);
									}
									else
									{
										byte[] ct = (byte[])oin2.readObject();
										ObjectOutputStream dout2 = new ObjectOutputStream(s.getOutputStream());					
										dout2.writeObject("success");
										dout2.writeObject(ct);
									}
								}
								else if(msg2.equalsIgnoreCase("failure"))
								{
									ObjectOutputStream dout2 = new ObjectOutputStream(s.getOutputStream());					
									dout2.writeObject("failure");
									
								}
								else if(msg2.equalsIgnoreCase("not"))
								{
									//3
									Socket sc3 = new Socket("localhost",803);
									ObjectOutputStream dout4 = new ObjectOutputStream(sc3.getOutputStream());					
									dout4.writeObject(filename);
									dout4.writeObject(sk);
									dout4.writeObject(ip);
									
									ObjectInputStream oin3 = new ObjectInputStream(sc3.getInputStream());
									String msg3 =(String)oin3.readObject();
									System.out.println(msg3);
									
									
									if(msg3.equalsIgnoreCase("success"))
									{
										if (filename.toLowerCase().endsWith(".java")
												|| filename.toLowerCase().endsWith(".txt")
												|| filename.toLowerCase().endsWith(".log"))
										{
											String ct = (String)oin3.readObject();
											ObjectOutputStream dout2 = new ObjectOutputStream(s.getOutputStream());					
											dout2.writeObject("success");
											dout2.writeObject(ct);
										}
										else
										{
											byte[] ct = (byte[])oin3.readObject();
											ObjectOutputStream dout2 = new ObjectOutputStream(s.getOutputStream());					
											dout2.writeObject("success");
											dout2.writeObject(ct);
										}
									}
									else if(msg3.equalsIgnoreCase("failure"))
									{
										ObjectOutputStream dout2 = new ObjectOutputStream(s.getOutputStream());					
										dout2.writeObject("failure");
										
									}
									else if(msg3.equalsIgnoreCase("not"))
									{
										Socket sp = new Socket("localhost",900);
										ObjectOutputStream dout5 = new ObjectOutputStream(sp.getOutputStream());					
										dout5.writeObject(filename);
										dout5.writeObject(sk);
										dout5.writeObject(ip);
										dout5.writeObject(dname);
									
										ObjectInputStream oin4 = new ObjectInputStream(sp.getInputStream());
										String msg4 =(String)oin4.readObject();
										System.out.println(msg4);
										if(msg4.equalsIgnoreCase("success"))
										{
											
											String filename1 = (String)oin4.readObject();
											 if (filename1.toLowerCase().endsWith(".java")
														|| filename1.toLowerCase().endsWith(".txt")
														|| filename1.toLowerCase().endsWith(".log"))
												{
											 String content = (String) oin4.readObject();
											 String sk1=(String)oin4.readObject();
											 String sip=(String)oin4.readObject();
											 
											 lbs1.setVisible(false);
											 lbs1.setIcon(gs1);
											 lbs1.setVisible(true);
											 
											 
											 Random r1 = new Random();
											 
											 tn1 = r1.nextInt(50);
											 tn2= r1.nextInt(50);
											 tn3 = r1.nextInt(50);
											
											 l1.setVisible(false);
											 l1.setText(Integer.toString(tn1));
											 l1.setVisible(true);
											 
											 l2.setVisible(false);
											 l2.setText(Integer.toString(tn2));
											 l2.setVisible(true);
											 
											 l3.setVisible(false);
											 l3.setText(Integer.toString(tn3));
											 l3.setVisible(true);
											 
											 Thread.sleep(1000);
											 
											
											 
											 if(tn1<=tn2 && tn1<=tn3)
											 {
												 li1.setVisible(false);
												 li1.setIcon(g1);
												 li1.setVisible(true);
												 Thread.sleep(1000);
												 
												 lbn1.setVisible(false);
												 lbn1.setIcon(gn1);
												 lbn1.setVisible(true);
												 Thread.sleep(1000);
												 
												 li6.setVisible(false);
												 li6.setIcon(g4);
												 li6.setVisible(true);
												 Thread.sleep(1000);
												 
												 lbn4.setVisible(false);
												 lbn4.setIcon(gn4);
												 lbn4.setVisible(true);
												 Thread.sleep(1000);
												 
												 li11.setVisible(false);
												 li11.setIcon(g4);
												 li11.setVisible(true);
												 Thread.sleep(1000);
												 
												 lbn7.setVisible(false);
												 lbn7.setIcon(gn7);
												 lbn7.setVisible(true);
												 Thread.sleep(1000);
												 
												 li21.setVisible(false);
												 li21.setIcon(g14);
												 li21.setVisible(true);
												 Thread.sleep(1000);
												 
												 lbn10.setVisible(false);
												 lbn10.setIcon(gn10);
												 lbn10.setVisible(true);
												 Thread.sleep(1000);
												 
												 
												 Socket sc11 = new Socket("localhost",701);
						        				 ObjectOutputStream dout11 = new ObjectOutputStream(sc11.getOutputStream());
						        				 dout11.writeObject(filename1);
						        				 dout11.writeObject(content);
						        				
						        				 dout11.writeObject(sk1);
						        				 dout11.writeObject(sip);
						        				 
						        				 ObjectInputStream din1 = new ObjectInputStream(sc11.getInputStream());
						        				 String msg11 = (String)din1.readObject();
						        				 if(msg11.equalsIgnoreCase("success"))
												 {
													 JOptionPane.showMessageDialog(null,"File Uploaded to NCL-10");
												 }
						        				 
						        				 li26.setVisible(false);
												 li26.setIcon(g4);
												 li26.setVisible(true);
												 Thread.sleep(1000);
												 
												 lbn13.setVisible(false);
												 lbn13.setIcon(gn13);
												 lbn13.setVisible(true);
												 Thread.sleep(1000);
						        				 
												 li211.setVisible(false);
												 li211.setIcon(g5);
												 li211.setVisible(true);
												 Thread.sleep(1000);
												 
												 lbd1.setVisible(false);
												 lbd1.setIcon(gd1);
												 lbd1.setVisible(true);
												 Thread.sleep(1000);
												 
												 ObjectOutputStream dout2 = new ObjectOutputStream(s.getOutputStream());					
													dout2.writeObject("success");
													dout2.writeObject(content);
												 
											 }
											 else if(tn2<=tn1 && tn2<=tn3)
											 {
												 li2.setVisible(false);
												 li2.setIcon(g2);
												 li2.setVisible(true);
												 Thread.sleep(1000);
												 
												 lbn2.setVisible(false);
												 lbn2.setIcon(gn2);
												 lbn2.setVisible(true);
												 Thread.sleep(1000);
												 
												 li7.setVisible(false);
												 li7.setIcon(g4);
												 li7.setVisible(true);
												 Thread.sleep(1000);
												 
												 lbn5.setVisible(false);
												 lbn5.setIcon(gn5);
												 lbn5.setVisible(true);
												 Thread.sleep(1000);
												 
												 li12.setVisible(false);
												 li12.setIcon(g4);
												 li12.setVisible(true);
												 Thread.sleep(1000);
												 
												 lbn8.setVisible(false);
												 lbn8.setIcon(gn8);
												 lbn8.setVisible(true);
												 Thread.sleep(1000);
												 
												 li22.setVisible(false);
												 li22.setIcon(g14);
												 li22.setVisible(true);
												 Thread.sleep(1000);
												 
												 lbn11.setVisible(false);
												 lbn11.setIcon(gn11);
												 lbn11.setVisible(true);
												 Thread.sleep(1000);
												 
												 
												 Socket sc12 = new Socket("localhost",702);
						        				 ObjectOutputStream dout12 = new ObjectOutputStream(sc12.getOutputStream());
						        				 dout12.writeObject(filename1);
						        				 dout12.writeObject(content);
						        				
						        				 dout12.writeObject(sk1);
						        				 dout12.writeObject(sip);
						        				 
						        				 ObjectInputStream din1 = new ObjectInputStream(sc12.getInputStream());
						        				 String msg12 = (String)din1.readObject();
						        				 if(msg12.equalsIgnoreCase("success"))
												 {
													 JOptionPane.showMessageDialog(null,"File Uploaded to NCL-11");
												 }
						        				 
						        				 li27.setVisible(false);
												 li27.setIcon(g4);
												 li27.setVisible(true);
												 Thread.sleep(1000);
												 
												 lbn14.setVisible(false);
												 lbn14.setIcon(gn14);
												 lbn14.setVisible(true);
												 Thread.sleep(1000);
						        				 
												 li212.setVisible(false);
												 li212.setIcon(g2);
												 li212.setVisible(true);
												 Thread.sleep(1000);
												 
												 lbd1.setVisible(false);
												 lbd1.setIcon(gd1);
												 lbd1.setVisible(true);
												 Thread.sleep(1000);
												 
												 ObjectOutputStream dout2 = new ObjectOutputStream(s.getOutputStream());					
													dout2.writeObject("success");
													dout2.writeObject(content);
											 }
											 else  if(tn3<=tn2 && tn3<=tn1)
											 {
												 li3.setVisible(false);
												 li3.setIcon(g3);
												 li3.setVisible(true);
												 Thread.sleep(1000);
												 
												 lbn3.setVisible(false);
												 lbn3.setIcon(gn3);
												 lbn3.setVisible(true);
												 Thread.sleep(1000);
												 
												 li8.setVisible(false);
												 li8.setIcon(g4);
												 li8.setVisible(true);
												 Thread.sleep(1000);
												 
												 lbn6.setVisible(false);
												 lbn6.setIcon(gn6);
												 lbn6.setVisible(true);
												 Thread.sleep(1000);
												 
												 li13.setVisible(false);
												 li13.setIcon(g4);
												 li13.setVisible(true);
												 Thread.sleep(1000);
												 
												 lbn9.setVisible(false);
												 lbn9.setIcon(gn9);
												 lbn9.setVisible(true);
												 Thread.sleep(1000);
												 
												 li23.setVisible(false);
												 li23.setIcon(g4);
												 li23.setVisible(true);
												 Thread.sleep(1000);
												 
												 lbn12.setVisible(false);
												 lbn12.setIcon(gn12);
												 lbn12.setVisible(true);
												 Thread.sleep(1000);
												 
												 
												 Socket sc13 = new Socket("localhost",703);
						        				 ObjectOutputStream dout13 = new ObjectOutputStream(sc13.getOutputStream());
						        				 dout13.writeObject(filename1);
						        				 dout13.writeObject(content);
						        				
						        				 dout13.writeObject(sk1);
						        				 dout13.writeObject(sip);
						        				 
						        				 ObjectInputStream din1 = new ObjectInputStream(sc13.getInputStream());
						        				 String msg13 = (String)din1.readObject();
						        				 if(msg13.equalsIgnoreCase("success"))
												 {
													 JOptionPane.showMessageDialog(null,"File Uploaded to NCL-12");
												 }
						        				 
						        				 li28.setVisible(false);
												 li28.setIcon(g4);
												 li28.setVisible(true);
												 Thread.sleep(1000);
												 
												 lbn15.setVisible(false);
												 lbn15.setIcon(gn15);
												 lbn15.setVisible(true);
												 Thread.sleep(1000);
						        				 
												 li213.setVisible(false);
												 li213.setIcon(g6);
												 li213.setVisible(true);
												 Thread.sleep(1000);
												 
												 lbd1.setVisible(false);
												 lbd1.setIcon(gd1);
												 lbd1.setVisible(true);
												 Thread.sleep(1000);
												 ObjectOutputStream dout2 = new ObjectOutputStream(s.getOutputStream());					
													dout2.writeObject("success");
													dout2.writeObject(content);
											 }
											 
											
												}
											 else
											 {
												 byte[] content = (byte[])oin4.readObject();
												 String sk1=(String)oin4.readObject();
												
												 String sip=(String)oin4.readObject();
												 
												 lbs1.setVisible(false);
												 lbs1.setIcon(gs1);
												 lbs1.setVisible(true);
												 
												 
												 Random r1 = new Random();
												 
												 tn1 = r1.nextInt(50);
												 tn2= r1.nextInt(50);
												 tn3 = r1.nextInt(50);
												
												 l1.setVisible(false);
												 l1.setText(Integer.toString(tn1));
												 l1.setVisible(true);
												 
												 l2.setVisible(false);
												 l2.setText(Integer.toString(tn2));
												 l2.setVisible(true);
												 
												 l3.setVisible(false);
												 l3.setText(Integer.toString(tn3));
												 l3.setVisible(true);
												 
												 Thread.sleep(1000);
												 
												
												 
												 if(tn1<=tn2 && tn1<=tn3)
												 {
													 li1.setVisible(false);
													 li1.setIcon(g1);
													 li1.setVisible(true);
													 Thread.sleep(1000);
													 
													 lbn1.setVisible(false);
													 lbn1.setIcon(gn1);
													 lbn1.setVisible(true);
													 Thread.sleep(1000);
													 
													 li6.setVisible(false);
													 li6.setIcon(g4);
													 li6.setVisible(true);
													 Thread.sleep(1000);
													 
													 lbn4.setVisible(false);
													 lbn4.setIcon(gn4);
													 lbn4.setVisible(true);
													 Thread.sleep(1000);
													 
													 li11.setVisible(false);
													 li11.setIcon(g4);
													 li11.setVisible(true);
													 Thread.sleep(1000);
													 
													 lbn7.setVisible(false);
													 lbn7.setIcon(gn7);
													 lbn7.setVisible(true);
													 Thread.sleep(1000);
													 
													 li21.setVisible(false);
													 li21.setIcon(g14);
													 li21.setVisible(true);
													 Thread.sleep(1000);
													 
													 lbn10.setVisible(false);
													 lbn10.setIcon(gn10);
													 lbn10.setVisible(true);
													 Thread.sleep(1000);
													 
													 
													 Socket sc11 = new Socket("localhost",701);
							        				 ObjectOutputStream dout11 = new ObjectOutputStream(sc11.getOutputStream());
							        				 dout11.writeObject(filename1);
							        				 dout11.writeObject(content);
							        				
							        				 dout11.writeObject(sk1);
							        				 dout11.writeObject(sip);
							        				 
							        				 ObjectInputStream din1 = new ObjectInputStream(sc11.getInputStream());
							        				 String msg11 = (String)din1.readObject();
							        				 if(msg11.equalsIgnoreCase("success"))
													 {
														 JOptionPane.showMessageDialog(null,"File Uploaded to NCL-10");
													 }
							        				 
							        				 li26.setVisible(false);
													 li26.setIcon(g4);
													 li26.setVisible(true);
													 Thread.sleep(1000);
													 
													 lbn13.setVisible(false);
													 lbn13.setIcon(gn13);
													 lbn13.setVisible(true);
													 Thread.sleep(1000);
							        				 
													 li211.setVisible(false);
													 li211.setIcon(g5);
													 li211.setVisible(true);
													 Thread.sleep(1000);
													 
													 lbd1.setVisible(false);
													 lbd1.setIcon(gd1);
													 lbd1.setVisible(true);
													 Thread.sleep(1000);
													 
													 ObjectOutputStream dout2 = new ObjectOutputStream(s.getOutputStream());					
														dout2.writeObject("success");
														dout2.writeObject(content);
													 
												 }
												 else if(tn2<=tn1 && tn2<=tn3)
												 {
													 li2.setVisible(false);
													 li2.setIcon(g2);
													 li2.setVisible(true);
													 Thread.sleep(1000);
													 
													 lbn2.setVisible(false);
													 lbn2.setIcon(gn2);
													 lbn2.setVisible(true);
													 Thread.sleep(1000);
													 
													 li7.setVisible(false);
													 li7.setIcon(g4);
													 li7.setVisible(true);
													 Thread.sleep(1000);
													 
													 lbn5.setVisible(false);
													 lbn5.setIcon(gn5);
													 lbn5.setVisible(true);
													 Thread.sleep(1000);
													 
													 li12.setVisible(false);
													 li12.setIcon(g4);
													 li12.setVisible(true);
													 Thread.sleep(1000);
													 
													 lbn8.setVisible(false);
													 lbn8.setIcon(gn8);
													 lbn8.setVisible(true);
													 Thread.sleep(1000);
													 
													 li22.setVisible(false);
													 li22.setIcon(g14);
													 li22.setVisible(true);
													 Thread.sleep(1000);
													 
													 lbn11.setVisible(false);
													 lbn11.setIcon(gn11);
													 lbn11.setVisible(true);
													 Thread.sleep(1000);
													 
													 
													 Socket sc12 = new Socket("localhost",702);
							        				 ObjectOutputStream dout12 = new ObjectOutputStream(sc12.getOutputStream());
							        				 dout12.writeObject(filename1);
							        				 dout12.writeObject(content);
							        				
							        				 dout12.writeObject(sk1);
							        				 dout12.writeObject(sip);
							        				 
							        				 ObjectInputStream din1 = new ObjectInputStream(sc12.getInputStream());
							        				 String msg12 = (String)din1.readObject();
							        				 if(msg12.equalsIgnoreCase("success"))
													 {
														 JOptionPane.showMessageDialog(null,"File Uploaded to NCL-11");
													 }
							        				 
							        				 li27.setVisible(false);
													 li27.setIcon(g4);
													 li27.setVisible(true);
													 Thread.sleep(1000);
													 
													 lbn14.setVisible(false);
													 lbn14.setIcon(gn14);
													 lbn14.setVisible(true);
													 Thread.sleep(1000);
							        				 
													 li212.setVisible(false);
													 li212.setIcon(g2);
													 li212.setVisible(true);
													 Thread.sleep(1000);
													 
													 lbd1.setVisible(false);
													 lbd1.setIcon(gd1);
													 lbd1.setVisible(true);
													 Thread.sleep(1000);
													 ObjectOutputStream dout2 = new ObjectOutputStream(s.getOutputStream());					
														dout2.writeObject("success");
														dout2.writeObject(content);
												 }
												 else  if(tn3<=tn2 && tn3<=tn1)
												 {
													 li3.setVisible(false);
													 li3.setIcon(g3);
													 li3.setVisible(true);
													 Thread.sleep(1000);
													 
													 lbn3.setVisible(false);
													 lbn3.setIcon(gn3);
													 lbn3.setVisible(true);
													 Thread.sleep(1000);
													 
													 li8.setVisible(false);
													 li8.setIcon(g4);
													 li8.setVisible(true);
													 Thread.sleep(1000);
													 
													 lbn6.setVisible(false);
													 lbn6.setIcon(gn6);
													 lbn6.setVisible(true);
													 Thread.sleep(1000);
													 
													 li13.setVisible(false);
													 li13.setIcon(g4);
													 li13.setVisible(true);
													 Thread.sleep(1000);
													 
													 lbn9.setVisible(false);
													 lbn9.setIcon(gn9);
													 lbn9.setVisible(true);
													 Thread.sleep(1000);
													 
													 li23.setVisible(false);
													 li23.setIcon(g4);
													 li23.setVisible(true);
													 Thread.sleep(1000);
													 
													 lbn12.setVisible(false);
													 lbn12.setIcon(gn12);
													 lbn12.setVisible(true);
													 Thread.sleep(1000);
													 
													 
													 Socket sc13 = new Socket("localhost",703);
							        				 ObjectOutputStream dout13 = new ObjectOutputStream(sc13.getOutputStream());
							        				 dout13.writeObject(filename1);
							        				 dout13.writeObject(content);
							        				
							        				 dout13.writeObject(sk1);
							        				 dout13.writeObject(sip);
							        				 
							        				 ObjectInputStream din1 = new ObjectInputStream(sc13.getInputStream());
							        				 String msg13 = (String)din1.readObject();
							        				 if(msg13.equalsIgnoreCase("success"))
													 {
														 JOptionPane.showMessageDialog(null,"File Uploaded to NCL-12");
													 }
							        				 
							        				 li28.setVisible(false);
													 li28.setIcon(g4);
													 li28.setVisible(true);
													 Thread.sleep(1000);
													 
													 lbn15.setVisible(false);
													 lbn15.setIcon(gn15);
													 lbn15.setVisible(true);
													 Thread.sleep(1000);
							        				 
													 li213.setVisible(false);
													 li213.setIcon(g6);
													 li213.setVisible(true);
													 Thread.sleep(1000);
													 
													 lbd1.setVisible(false);
													 lbd1.setIcon(gd1);
													 lbd1.setVisible(true);
													 Thread.sleep(1000);
													 ObjectOutputStream dout2 = new ObjectOutputStream(s.getOutputStream());					
														dout2.writeObject("success");
														dout2.writeObject(content);
												 }
												 
												 
											 }
											
										
										}
										else if(msg4.equalsIgnoreCase("fail"))
										{
											ObjectOutputStream dout2 = new ObjectOutputStream(s.getOutputStream());					
											dout2.writeObject("not");
										}
										
										
									}
								
									
								}
							
								
							}
							
							
							
							}
							
							
							
							}
						
					
				catch(Exception e1)
				{
					e1.printStackTrace();
				}
			}
			if(this.port==202)
			{
				
				try
				{
					DBCon db = new DBCon();
					 Connection con = db.getConnection();
					 
					ServerSocket sc = new ServerSocket(202);
					while(true)
					{
						Socket s = sc.accept();
						ObjectInputStream din = new ObjectInputStream(s.getInputStream());
					
					 String filename = (String)din.readObject();
					 if (filename.toLowerCase().endsWith(".java")
								|| filename.toLowerCase().endsWith(".txt")
								|| filename.toLowerCase().endsWith(".log"))
						{
					 String content = (String) din.readObject();
					 String sk=(String)din.readObject();
					 String dname=(String)din.readObject();
					 String dip=(String)din.readObject();
					 String sip=(String)din.readObject();
					 
					 lbs1.setVisible(false);
					 lbs1.setIcon(gs1);
					 lbs1.setVisible(true);
					 
					 
					 Random r1 = new Random();
					 
					 tn1 = r1.nextInt(50);
					 tn2= r1.nextInt(50);
					 tn3 = r1.nextInt(50);
					
					 l1.setVisible(false);
					 l1.setText(Integer.toString(tn1));
					 l1.setVisible(true);
					 
					 l2.setVisible(false);
					 l2.setText(Integer.toString(tn2));
					 l2.setVisible(true);
					 
					 l3.setVisible(false);
					 l3.setText(Integer.toString(tn3));
					 l3.setVisible(true);
					 
					 Thread.sleep(1000);
					 
					
					 
					 if(tn1<=tn2 && tn1<=tn3)
					 {
						 li1.setVisible(false);
						 li1.setIcon(g1);
						 li1.setVisible(true);
						 Thread.sleep(1000);
						 
						 lbn1.setVisible(false);
						 lbn1.setIcon(gn1);
						 lbn1.setVisible(true);
						 Thread.sleep(1000);
						 
						 li6.setVisible(false);
						 li6.setIcon(g4);
						 li6.setVisible(true);
						 Thread.sleep(1000);
						 
						 lbn4.setVisible(false);
						 lbn4.setIcon(gn4);
						 lbn4.setVisible(true);
						 Thread.sleep(1000);
						 
						 li11.setVisible(false);
						 li11.setIcon(g4);
						 li11.setVisible(true);
						 Thread.sleep(1000);
						 
						 lbn7.setVisible(false);
						 lbn7.setIcon(gn7);
						 lbn7.setVisible(true);
						 Thread.sleep(1000);
						 
						 li21.setVisible(false);
						 li21.setIcon(g14);
						 li21.setVisible(true);
						 Thread.sleep(1000);
						 
						 lbn10.setVisible(false);
						 lbn10.setIcon(gn10);
						 lbn10.setVisible(true);
						 Thread.sleep(1000);
						 
						 
						 Socket sc1 = new Socket("localhost",701);
        				 ObjectOutputStream dout1 = new ObjectOutputStream(sc1.getOutputStream());
        				 dout1.writeObject(filename);
        				 dout1.writeObject(content);
        				
        				 dout1.writeObject(sk);
        				 dout1.writeObject(sip);
        				 
        				 ObjectInputStream din1 = new ObjectInputStream(sc1.getInputStream());
        				 String msg1 = (String)din1.readObject();
        				 if(msg1.equalsIgnoreCase("success"))
						 {
							 JOptionPane.showMessageDialog(null,"File Uploaded to NCL-10");
						 }
        				 
        				 li26.setVisible(false);
						 li26.setIcon(g4);
						 li26.setVisible(true);
						 Thread.sleep(1000);
						 
						 lbn13.setVisible(false);
						 lbn13.setIcon(gn13);
						 lbn13.setVisible(true);
						 Thread.sleep(1000);
        				 
						 li211.setVisible(false);
						 li211.setIcon(g5);
						 li211.setVisible(true);
						 Thread.sleep(1000);
						 
						 lbd1.setVisible(false);
						 lbd1.setIcon(gd1);
						 lbd1.setVisible(true);
						 Thread.sleep(1000);
						 funcnD1(s,dname,dip,content,filename);
						 
					 }
					 else if(tn2<=tn1 && tn2<=tn3)
					 {
						 li2.setVisible(false);
						 li2.setIcon(g2);
						 li2.setVisible(true);
						 Thread.sleep(1000);
						 
						 lbn2.setVisible(false);
						 lbn2.setIcon(gn2);
						 lbn2.setVisible(true);
						 Thread.sleep(1000);
						 
						 li7.setVisible(false);
						 li7.setIcon(g4);
						 li7.setVisible(true);
						 Thread.sleep(1000);
						 
						 lbn5.setVisible(false);
						 lbn5.setIcon(gn5);
						 lbn5.setVisible(true);
						 Thread.sleep(1000);
						 
						 li12.setVisible(false);
						 li12.setIcon(g4);
						 li12.setVisible(true);
						 Thread.sleep(1000);
						 
						 lbn8.setVisible(false);
						 lbn8.setIcon(gn8);
						 lbn8.setVisible(true);
						 Thread.sleep(1000);
						 
						 li22.setVisible(false);
						 li22.setIcon(g14);
						 li22.setVisible(true);
						 Thread.sleep(1000);
						 
						 lbn11.setVisible(false);
						 lbn11.setIcon(gn11);
						 lbn11.setVisible(true);
						 Thread.sleep(1000);
						 
						 
						 Socket sc1 = new Socket("localhost",702);
        				 ObjectOutputStream dout1 = new ObjectOutputStream(sc1.getOutputStream());
        				 dout1.writeObject(filename);
        				 dout1.writeObject(content);
        				
        				 dout1.writeObject(sk);
        				 dout1.writeObject(sip);
        				 
        				 ObjectInputStream din1 = new ObjectInputStream(sc1.getInputStream());
        				 String msg1 = (String)din1.readObject();
        				 if(msg1.equalsIgnoreCase("success"))
						 {
							 JOptionPane.showMessageDialog(null,"File Uploaded to NCL-11");
						 }
        				 
        				 li27.setVisible(false);
						 li27.setIcon(g4);
						 li27.setVisible(true);
						 Thread.sleep(1000);
						 
						 lbn14.setVisible(false);
						 lbn14.setIcon(gn14);
						 lbn14.setVisible(true);
						 Thread.sleep(1000);
        				 
						 li212.setVisible(false);
						 li212.setIcon(g2);
						 li212.setVisible(true);
						 Thread.sleep(1000);
						 
						 lbd1.setVisible(false);
						 lbd1.setIcon(gd1);
						 lbd1.setVisible(true);
						 Thread.sleep(1000);
						 funcnD1(s,dname,dip,content,filename);
					 }
					 else  if(tn3<=tn2 && tn3<=tn1)
					 {
						 li3.setVisible(false);
						 li3.setIcon(g3);
						 li3.setVisible(true);
						 Thread.sleep(1000);
						 
						 lbn3.setVisible(false);
						 lbn3.setIcon(gn3);
						 lbn3.setVisible(true);
						 Thread.sleep(1000);
						 
						 li8.setVisible(false);
						 li8.setIcon(g4);
						 li8.setVisible(true);
						 Thread.sleep(1000);
						 
						 lbn6.setVisible(false);
						 lbn6.setIcon(gn6);
						 lbn6.setVisible(true);
						 Thread.sleep(1000);
						 
						 li13.setVisible(false);
						 li13.setIcon(g4);
						 li13.setVisible(true);
						 Thread.sleep(1000);
						 
						 lbn9.setVisible(false);
						 lbn9.setIcon(gn9);
						 lbn9.setVisible(true);
						 Thread.sleep(1000);
						 
						 li23.setVisible(false);
						 li23.setIcon(g4);
						 li23.setVisible(true);
						 Thread.sleep(1000);
						 
						 lbn12.setVisible(false);
						 lbn12.setIcon(gn12);
						 lbn12.setVisible(true);
						 Thread.sleep(1000);
						 
						 
						 Socket sc1 = new Socket("localhost",703);
        				 ObjectOutputStream dout1 = new ObjectOutputStream(sc1.getOutputStream());
        				 dout1.writeObject(filename);
        				 dout1.writeObject(content);
        				
        				 dout1.writeObject(sk);
        				 dout1.writeObject(sip);
        				 
        				 ObjectInputStream din1 = new ObjectInputStream(sc1.getInputStream());
        				 String msg1 = (String)din1.readObject();
        				 if(msg1.equalsIgnoreCase("success"))
						 {
							 JOptionPane.showMessageDialog(null,"File Uploaded to NCL-12");
						 }
        				 
        				 li28.setVisible(false);
						 li28.setIcon(g4);
						 li28.setVisible(true);
						 Thread.sleep(1000);
						 
						 lbn15.setVisible(false);
						 lbn15.setIcon(gn15);
						 lbn15.setVisible(true);
						 Thread.sleep(1000);
        				 
						 li213.setVisible(false);
						 li213.setIcon(g6);
						 li213.setVisible(true);
						 Thread.sleep(1000);
						 
						 lbd1.setVisible(false);
						 lbd1.setIcon(gd1);
						 lbd1.setVisible(true);
						 Thread.sleep(1000);
						 funcnD1(s,dname,dip,content,filename);
					 }
					 
					
						}
					 else
					 {
						 byte[] content = (byte[])din.readObject();
						 String sk=(String)din.readObject();
						 String dname=(String)din.readObject();
						 String dip=(String)din.readObject();
						 String sip=(String)din.readObject();
						 
						 lbs1.setVisible(false);
						 lbs1.setIcon(gs1);
						 lbs1.setVisible(true);
						 
						 
						 Random r1 = new Random();
						 
						 tn1 = r1.nextInt(50);
						 tn2= r1.nextInt(50);
						 tn3 = r1.nextInt(50);
						
						 l1.setVisible(false);
						 l1.setText(Integer.toString(tn1));
						 l1.setVisible(true);
						 
						 l2.setVisible(false);
						 l2.setText(Integer.toString(tn2));
						 l2.setVisible(true);
						 
						 l3.setVisible(false);
						 l3.setText(Integer.toString(tn3));
						 l3.setVisible(true);
						 
						 Thread.sleep(1000);
						 
						
						 
						 if(tn1<=tn2 && tn1<=tn3)
						 {
							 li1.setVisible(false);
							 li1.setIcon(g1);
							 li1.setVisible(true);
							 Thread.sleep(1000);
							 
							 lbn1.setVisible(false);
							 lbn1.setIcon(gn1);
							 lbn1.setVisible(true);
							 Thread.sleep(1000);
							 
							 li6.setVisible(false);
							 li6.setIcon(g4);
							 li6.setVisible(true);
							 Thread.sleep(1000);
							 
							 lbn4.setVisible(false);
							 lbn4.setIcon(gn4);
							 lbn4.setVisible(true);
							 Thread.sleep(1000);
							 
							 li11.setVisible(false);
							 li11.setIcon(g4);
							 li11.setVisible(true);
							 Thread.sleep(1000);
							 
							 lbn7.setVisible(false);
							 lbn7.setIcon(gn7);
							 lbn7.setVisible(true);
							 Thread.sleep(1000);
							 
							 li21.setVisible(false);
							 li21.setIcon(g14);
							 li21.setVisible(true);
							 Thread.sleep(1000);
							 
							 lbn10.setVisible(false);
							 lbn10.setIcon(gn10);
							 lbn10.setVisible(true);
							 Thread.sleep(1000);
							 
							 
							 Socket sc1 = new Socket("localhost",701);
	        				 ObjectOutputStream dout1 = new ObjectOutputStream(sc1.getOutputStream());
	        				 dout1.writeObject(filename);
	        				 dout1.writeObject(content);
	        				
	        				 dout1.writeObject(sk);
	        				 dout1.writeObject(sip);
	        				 
	        				 ObjectInputStream din1 = new ObjectInputStream(sc1.getInputStream());
	        				 String msg1 = (String)din1.readObject();
	        				 if(msg1.equalsIgnoreCase("success"))
							 {
								 JOptionPane.showMessageDialog(null,"File Uploaded to NCL-10");
							 }
	        				 
	        				 li26.setVisible(false);
							 li26.setIcon(g4);
							 li26.setVisible(true);
							 Thread.sleep(1000);
							 
							 lbn13.setVisible(false);
							 lbn13.setIcon(gn13);
							 lbn13.setVisible(true);
							 Thread.sleep(1000);
	        				 
							 li211.setVisible(false);
							 li211.setIcon(g5);
							 li211.setVisible(true);
							 Thread.sleep(1000);
							 
							 lbd1.setVisible(false);
							 lbd1.setIcon(gd1);
							 lbd1.setVisible(true);
							 Thread.sleep(1000);
							 funcnD(s,dname,dip,content,filename);
							 
						 }
						 else if(tn2<=tn1 && tn2<=tn3)
						 {
							 li2.setVisible(false);
							 li2.setIcon(g2);
							 li2.setVisible(true);
							 Thread.sleep(1000);
							 
							 lbn2.setVisible(false);
							 lbn2.setIcon(gn2);
							 lbn2.setVisible(true);
							 Thread.sleep(1000);
							 
							 li7.setVisible(false);
							 li7.setIcon(g4);
							 li7.setVisible(true);
							 Thread.sleep(1000);
							 
							 lbn5.setVisible(false);
							 lbn5.setIcon(gn5);
							 lbn5.setVisible(true);
							 Thread.sleep(1000);
							 
							 li12.setVisible(false);
							 li12.setIcon(g4);
							 li12.setVisible(true);
							 Thread.sleep(1000);
							 
							 lbn8.setVisible(false);
							 lbn8.setIcon(gn8);
							 lbn8.setVisible(true);
							 Thread.sleep(1000);
							 
							 li22.setVisible(false);
							 li22.setIcon(g14);
							 li22.setVisible(true);
							 Thread.sleep(1000);
							 
							 lbn11.setVisible(false);
							 lbn11.setIcon(gn11);
							 lbn11.setVisible(true);
							 Thread.sleep(1000);
							 
							 
							 Socket sc1 = new Socket("localhost",702);
	        				 ObjectOutputStream dout1 = new ObjectOutputStream(sc1.getOutputStream());
	        				 dout1.writeObject(filename);
	        				 dout1.writeObject(content);
	        				
	        				 dout1.writeObject(sk);
	        				 dout1.writeObject(sip);
	        				 
	        				 ObjectInputStream din1 = new ObjectInputStream(sc1.getInputStream());
	        				 String msg1 = (String)din1.readObject();
	        				 if(msg1.equalsIgnoreCase("success"))
							 {
								 JOptionPane.showMessageDialog(null,"File Uploaded to NCL-11");
							 }
	        				 
	        				 li27.setVisible(false);
							 li27.setIcon(g4);
							 li27.setVisible(true);
							 Thread.sleep(1000);
							 
							 lbn14.setVisible(false);
							 lbn14.setIcon(gn14);
							 lbn14.setVisible(true);
							 Thread.sleep(1000);
	        				 
							 li212.setVisible(false);
							 li212.setIcon(g2);
							 li212.setVisible(true);
							 Thread.sleep(1000);
							 
							 lbd1.setVisible(false);
							 lbd1.setIcon(gd1);
							 lbd1.setVisible(true);
							 Thread.sleep(1000);
							 funcnD(s,dname,dip,content,filename);
						 }
						 else  if(tn3<=tn2 && tn3<=tn1)
						 {
							 li3.setVisible(false);
							 li3.setIcon(g3);
							 li3.setVisible(true);
							 Thread.sleep(1000);
							 
							 lbn3.setVisible(false);
							 lbn3.setIcon(gn3);
							 lbn3.setVisible(true);
							 Thread.sleep(1000);
							 
							 li8.setVisible(false);
							 li8.setIcon(g4);
							 li8.setVisible(true);
							 Thread.sleep(1000);
							 
							 lbn6.setVisible(false);
							 lbn6.setIcon(gn6);
							 lbn6.setVisible(true);
							 Thread.sleep(1000);
							 
							 li13.setVisible(false);
							 li13.setIcon(g4);
							 li13.setVisible(true);
							 Thread.sleep(1000);
							 
							 lbn9.setVisible(false);
							 lbn9.setIcon(gn9);
							 lbn9.setVisible(true);
							 Thread.sleep(1000);
							 
							 li23.setVisible(false);
							 li23.setIcon(g4);
							 li23.setVisible(true);
							 Thread.sleep(1000);
							 
							 lbn12.setVisible(false);
							 lbn12.setIcon(gn12);
							 lbn12.setVisible(true);
							 Thread.sleep(1000);
							 
							 
							 Socket sc1 = new Socket("localhost",703);
	        				 ObjectOutputStream dout1 = new ObjectOutputStream(sc1.getOutputStream());
	        				 dout1.writeObject(filename);
	        				 dout1.writeObject(content);
	        				
	        				 dout1.writeObject(sk);
	        				 dout1.writeObject(sip);
	        				 
	        				 ObjectInputStream din1 = new ObjectInputStream(sc1.getInputStream());
	        				 String msg1 = (String)din1.readObject();
	        				 if(msg1.equalsIgnoreCase("success"))
							 {
								 JOptionPane.showMessageDialog(null,"File Uploaded to NCL-12");
							 }
	        				 
	        				 li28.setVisible(false);
							 li28.setIcon(g4);
							 li28.setVisible(true);
							 Thread.sleep(1000);
							 
							 lbn15.setVisible(false);
							 lbn15.setIcon(gn15);
							 lbn15.setVisible(true);
							 Thread.sleep(1000);
	        				 
							 li213.setVisible(false);
							 li213.setIcon(g6);
							 li213.setVisible(true);
							 Thread.sleep(1000);
							 
							 lbd1.setVisible(false);
							 lbd1.setIcon(gd1);
							 lbd1.setVisible(true);
							 Thread.sleep(1000);
							 funcnD(s,dname,dip,content,filename);
						 }
						 
						 
					 }
					
					}
				}catch(Exception e)
				{
					e.printStackTrace();
				}
			}
		}
	}
	public void funcnD1(Socket s,String dname,String dip,String content,String filename)
	{
		
		 
		try
		{
			
			
				
			 if(dname.equalsIgnoreCase("A"))   
             {
           	  Socket s3=new Socket(dip,101);
                 ObjectOutputStream dout=new ObjectOutputStream(s3.getOutputStream());
                 dout.writeObject(filename);   
                 dout.writeObject(content);
                    
                     ObjectInputStream dis = new ObjectInputStream(s3.getInputStream());
						String message = (String)dis.readObject();
						 ObjectOutputStream dout1=new ObjectOutputStream(s.getOutputStream());
                    dout1.writeObject(message+" By A");
             }
             if(dname.equalsIgnoreCase("B"))   
             {
           	  Socket s3=new Socket(dip,102);
                 ObjectOutputStream dout=new ObjectOutputStream(s3.getOutputStream());
                 dout.writeObject(filename);     
                 dout.writeObject(content);
                   
                     ObjectInputStream dis = new ObjectInputStream(s3.getInputStream());
						String message =(String) dis.readObject();
						 ObjectOutputStream dout1=new ObjectOutputStream(s.getOutputStream());
                    dout1.writeObject(message+" By B");
             }
             if(dname.equalsIgnoreCase("C"))   
             {
           	  Socket s3=new Socket(dip,103);
                 ObjectOutputStream dout=new ObjectOutputStream(s3.getOutputStream());
                 dout.writeObject(filename);      
                 dout.writeObject(content);
                    
                     ObjectInputStream dis = new ObjectInputStream(s3.getInputStream());
						String message = (String)dis.readObject();
						 ObjectOutputStream dout1=new ObjectOutputStream(s.getOutputStream());
                    dout1.writeObject(message+" By C");
             }
             if(dname.equalsIgnoreCase("D"))   
             {
           	  Socket s3=new Socket(dip,104);
                 ObjectOutputStream dout=new ObjectOutputStream(s3.getOutputStream());
                 dout.writeObject(filename);      
                 dout.writeObject(content);
                    
                     ObjectInputStream dis = new ObjectInputStream(s3.getInputStream());
						String message =(String) dis.readObject();
						 ObjectOutputStream dout1=new ObjectOutputStream(s.getOutputStream());
                    dout1.writeObject(message+" By D");
             }
             if(dname.equalsIgnoreCase("E"))   
             {
           	  Socket s3=new Socket(dip,105);
                 ObjectOutputStream dout=new ObjectOutputStream(s3.getOutputStream());
                 dout.writeObject(filename);      
                 dout.writeObject(content);
                
                     ObjectInputStream dis = new ObjectInputStream(s3.getInputStream());
						String message = (String)dis.readObject();
						 ObjectOutputStream dout1=new ObjectOutputStream(s.getOutputStream());
                    dout1.writeObject(message+" By E");
             }
             if(dname.equalsIgnoreCase("F"))   
             {
           	  Socket s3=new Socket(dip,106);
                 ObjectOutputStream dout=new ObjectOutputStream(s3.getOutputStream());
                 dout.writeObject(filename);      
                 dout.writeObject(content);
                  
                     ObjectInputStream dis = new ObjectInputStream(s3.getInputStream());
						String message = (String)dis.readObject();
						 ObjectOutputStream dout1=new ObjectOutputStream(s.getOutputStream());
                    dout1.writeObject(message+" By F");
             }
             Thread.sleep(2000);   
			refresh();
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public void funcnD(Socket s,String dname,String dip,byte [] content,String filename)
	{
		
		 
		try
		{
			
			
				
			 if(dname.equalsIgnoreCase("A"))   
             {
           	  Socket s3=new Socket(dip,101);
                 ObjectOutputStream dout=new ObjectOutputStream(s3.getOutputStream());
                 dout.writeObject(filename);   
                 dout.writeObject(content);
                    
                     ObjectInputStream dis = new ObjectInputStream(s3.getInputStream());
						String message = (String)dis.readObject();
						 ObjectOutputStream dout1=new ObjectOutputStream(s.getOutputStream());
                    dout1.writeObject(message+" By A");
             }
             if(dname.equalsIgnoreCase("B"))   
             {
           	  Socket s3=new Socket(dip,102);
                 ObjectOutputStream dout=new ObjectOutputStream(s3.getOutputStream());
                 dout.writeObject(filename);     
                 dout.writeObject(content);
                   
                     ObjectInputStream dis = new ObjectInputStream(s3.getInputStream());
						String message =(String) dis.readObject();
						 ObjectOutputStream dout1=new ObjectOutputStream(s.getOutputStream());
                    dout1.writeObject(message+" By B");
             }
             if(dname.equalsIgnoreCase("C"))   
             {
           	  Socket s3=new Socket(dip,103);
                 ObjectOutputStream dout=new ObjectOutputStream(s3.getOutputStream());
                 dout.writeObject(filename);      
                 dout.writeObject(content);
                    
                     ObjectInputStream dis = new ObjectInputStream(s3.getInputStream());
						String message = (String)dis.readObject();
						 ObjectOutputStream dout1=new ObjectOutputStream(s.getOutputStream());
                    dout1.writeObject(message+" By C");
             }
             if(dname.equalsIgnoreCase("D"))   
             {
           	  Socket s3=new Socket(dip,104);
                 ObjectOutputStream dout=new ObjectOutputStream(s3.getOutputStream());
                 dout.writeObject(filename);      
                 dout.writeObject(content);
                    
                     ObjectInputStream dis = new ObjectInputStream(s3.getInputStream());
						String message =(String) dis.readObject();
						 ObjectOutputStream dout1=new ObjectOutputStream(s.getOutputStream());
                    dout1.writeObject(message+" By D");
             }
             if(dname.equalsIgnoreCase("E"))   
             {
           	  Socket s3=new Socket(dip,105);
                 ObjectOutputStream dout=new ObjectOutputStream(s3.getOutputStream());
                 dout.writeObject(filename);      
                 dout.writeObject(content);
                
                     ObjectInputStream dis = new ObjectInputStream(s3.getInputStream());
						String message = (String)dis.readObject();
						 ObjectOutputStream dout1=new ObjectOutputStream(s.getOutputStream());
                    dout1.writeObject(message+" By E");
             }
             if(dname.equalsIgnoreCase("F"))   
             {
           	  Socket s3=new Socket(dip,106);
                 ObjectOutputStream dout=new ObjectOutputStream(s3.getOutputStream());
                 dout.writeObject(filename);      
                 dout.writeObject(content);
                  
                     ObjectInputStream dis = new ObjectInputStream(s3.getInputStream());
						String message = (String)dis.readObject();
						 ObjectOutputStream dout1=new ObjectOutputStream(s.getOutputStream());
                    dout1.writeObject(message+" By F");
             }
             Thread.sleep(2000);   
			refresh();
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public void actionPerformed(ActionEvent e)
	{
			
		/*if(e.getSource()==m3)
		{
		System.exit(0);
			
		}
		if(e.getSource()==mi1)
		{
			try
			{
			String[] dsname = { "Select Nodes", "N4", "N5", "N10", "N11" };
			
			String dataname = (String) JOptionPane.showInputDialog(null,
					"Select Nodes", "Node Name",
					JOptionPane.QUESTION_MESSAGE, null,  dsname,  dsname[0]);
			
			String bw1 = JOptionPane.showInputDialog(null,
					"Please Enter the BandWidth of Nodes");
			
			DBCon db = new DBCon();
			 Connection con = db.getConnection();
				
				String sql = "update Nodesinfo set bw='"+bw1+"' where Nname='"+dataname+"'";
				Statement stmt = con.createStatement();
				stmt.executeUpdate(sql);
				JOptionPane.showMessageDialog(null,"Bandwidth Allocated Successfully");
			
		}
		
		catch(Exception e1)
		{
			e1.printStackTrace();
		}
	}
		else if(e.getSource()==m2)
		{
			//Nodesinfo i2 = new Nodesinfo();
			try {
				UIManager
						.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			java.awt.EventQueue.invokeLater(new Runnable() {
				public void run() {
					//new Nodesinfo();
				}
			});
		}
		*/
		
	}
	
	public void refresh()
	{
		try
		{
			Thread.sleep(2000);
			l1.setVisible(false);
			l2.setVisible(false);
			l3.setVisible(false);
			
			lgd.setVisible(false);
			ln1ar.setVisible(false);
			lndar.setVisible(false);
			ln12d.setVisible(false);
			ld2n1.setVisible(false);
			lar10.setVisible(false);
			lar11.setVisible(false);
			lar12.setVisible(false);
			lg11.setVisible(false);
			lg12.setVisible(false);
			lg13.setVisible(false);
			l1.setVisible(false);
			l2.setVisible(false);
			l3.setVisible(false);
			
			 lbn1.setVisible(false);
			 lbn1.setIcon(bn1);
			 lbn1.setVisible(true);
			 
			 lbn2.setVisible(false);
			 lbn2.setIcon(bn2);
			 lbn2.setVisible(true);
			 
			 lbn3.setVisible(false);
			 lbn3.setIcon(bn3);
			 lbn3.setVisible(true);
			 
			 lbn4.setVisible(false);
			 lbn4.setIcon(bn4);
			 lbn4.setVisible(true);
			 
			 lbn5.setVisible(false);
			 lbn5.setIcon(bn5);
			 lbn5.setVisible(true);
			 
			 lbn6.setVisible(false);
			 lbn6.setIcon(bn6);
			 lbn6.setVisible(true);
			 
			 lbn7.setVisible(false);
			 lbn7.setIcon(bn7);
			 lbn7.setVisible(true);
			 
			 lbn8.setVisible(false);
			 lbn8.setIcon(bn8);
			 lbn8.setVisible(true);
			 
			 lbn9.setVisible(false);
			 lbn9.setIcon(bn9);
			 lbn9.setVisible(true);
			 
			 lbn10.setVisible(false);
			 lbn10.setIcon(bn10);
			 lbn10.setVisible(true);
			 
			 lbn11.setVisible(false);
			 lbn11.setIcon(bn11);
			 lbn11.setVisible(true);
			 
			 lbn12.setVisible(false);
			 lbn12.setIcon(bn12);
			 lbn12.setVisible(true);
			 
			 lbn13.setVisible(false);
			 lbn13.setIcon(bn13);
			 lbn13.setVisible(true);
			 
			 lbn14.setVisible(false);
			 lbn14.setIcon(bn14);
			 lbn14.setVisible(true);
			 
			 lbn15.setVisible(false);
			 lbn15.setIcon(bn15);
			 lbn15.setVisible(true);
			 
			 li21.setVisible(false);
			 li21.setIcon(i14);
			 li21.setVisible(true);
			 
			 li22.setVisible(false);
			 li22.setIcon(i14);
			 li22.setVisible(true);
			 
			 li23.setVisible(false);
			 li23.setIcon(i4);
			 li23.setVisible(true);
			 
			 li24.setVisible(false);
			 li24.setIcon(i7);
			 li24.setVisible(true);
			 
			 li25.setVisible(false);
			 li25.setIcon(i7);
			 li25.setVisible(true);
			 
			 li26.setVisible(false);
			 li26.setIcon(i4);
			 li26.setVisible(true);
			 
			 li27.setVisible(false);
			 li27.setIcon(i4);
			 li27.setVisible(true);
			 
			 li28.setVisible(false);
			 li28.setIcon(i4);
			 li28.setVisible(true);
			 
			 li29.setVisible(false);
			 li29.setIcon(i7);
			 li29.setVisible(true);
			 
			 li210.setVisible(false);
			 li210.setIcon(i7);
			 li210.setVisible(true);
			 
			 li211.setVisible(false);
			 li211.setIcon(i5);
			 li211.setVisible(true);
			 
			 li212.setVisible(false);
			 li212.setIcon(i2);
			 li212.setVisible(true);
			 
			 li213.setVisible(false);
			 li213.setIcon(i6);
			 li213.setVisible(true);
			 
	 			li1.setVisible(false);
				 li1.setIcon(i1);
				 li1.setVisible(true);
				 
				 li2.setVisible(false);
				 li2.setIcon(i2);
				 li2.setVisible(true);
				 
				 li3.setVisible(false);
				 li3.setIcon(i3);
				 li3.setVisible(true);
				 
				 li4.setVisible(false);
				 li4.setIcon(i7);
				 li4.setVisible(true);
				 
				 li5.setVisible(false);
				 li5.setIcon(i7);
				 li5.setVisible(true);
				 
				 li6.setVisible(false);
				 li6.setIcon(i4);
				 li6.setVisible(true);
				 
				 li7.setVisible(false);
				 li7.setIcon(i4);
				 li7.setVisible(true);
				 
				 li8.setVisible(false);
				 li8.setIcon(i4);
				 li8.setVisible(true);
				 
				 li9.setVisible(false);
				 li9.setIcon(i7);
				 li9.setVisible(true);
				 
				 li10.setVisible(false);
				 li10.setIcon(i7);
				 li10.setVisible(true);
				 
				 li11.setVisible(false);
				 li11.setIcon(i4);
				 li11.setVisible(true);
				 
				 li12.setVisible(false);
				 li12.setIcon(i4);
				 li12.setVisible(true);
				 
				 li13.setVisible(false);
				 li13.setIcon(i4);
				 li13.setVisible(true);
				 
				 li14.setVisible(false);
				 li14.setIcon(i7);
				 li14.setVisible(true);
				 
				 li15.setVisible(false);
				 li15.setIcon(i7);
				 li15.setVisible(true);
				 
				 lbd1.setVisible(false);
					lbd1.setIcon(bd1);
					 lbd1.setVisible(true);
					 
					 lbs1.setVisible(false);
						lbs1.setIcon(bs1);
						 lbs1.setVisible(true);
			 
	
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
		
		
	}
	
	
	
	public static void main(String[] args) {
		//new Router();
		try {
			UIManager
					.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new Router();
			}
		});
	}
	
	

}
